/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

export default class {

	get(key) {
		var val = localStorage.getItem(key);
		return JSON.parse(val);
	}

	set(key, obj) {
		var val = JSON.stringify(obj);
		localStorage.setItem(key, val);
	}

	del(key) {
		localStorage.removeItem(key);
	}

}
