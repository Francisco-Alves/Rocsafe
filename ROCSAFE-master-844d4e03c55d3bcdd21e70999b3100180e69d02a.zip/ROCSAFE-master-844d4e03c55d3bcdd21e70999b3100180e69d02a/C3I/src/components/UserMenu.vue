<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-menu :nudge-bottom="10" :close-on-content-click="false" v-model="menu" offset-y left>
		<user-profile :show="userProfile.showDialog" :avatar="user.img" @dismiss="dismiss"></user-profile>
		<v-btn slot="activator" icon large>
			<v-avatar size="40">
				<img v-img-fallback="imgFallback" ref="avatar" :src="user.avatar" alt="Avatar">
			</v-avatar>
		</v-btn>
		<v-card>
			<v-list>
				<v-list-tile @click="show">
					<v-list-tile-action>
						<v-icon :color="iconColor">person</v-icon>
					</v-list-tile-action>
					<v-list-tile-content>
						<v-list-tile-title>{{ user.name }}</v-list-tile-title>
					</v-list-tile-content>
				</v-list-tile>
				<v-list-tile v-if="user.email">
					<v-list-tile-action>
						<v-icon :color="iconColor">mail</v-icon>
					</v-list-tile-action>
					<v-list-tile-content>
						<v-list-tile-title>{{ user.email }}</v-list-tile-title>
					</v-list-tile-content>
				</v-list-tile>
				<v-list-tile>
					<v-list-tile-action>
						<v-icon :color="iconColor">security</v-icon>
					</v-list-tile-action>
					<v-list-tile-content>
						<v-list-tile-title>{{ user.role | snake2sentence }}</v-list-tile-title>
					</v-list-tile-content>
				</v-list-tile>
			</v-list>
			<v-card-actions>
				<v-btn class="mx-auto" @click="logout">
					Logout
					<v-icon right>mdi-logout-variant</v-icon>
				</v-btn>
			</v-card-actions>
		</v-card>
	</v-menu>
</template>

<script>
import UserProfile from './UserProfile.vue';

export default {
	components: {
		'user-profile': UserProfile
	},

	props: {
		'user': {
			type: Object,
			required: true
		},
		'imgBase': {
			type: String,
			required: true
		}
	},

	data() {
		return {
			menu: false,
			imgFallback: {
				loading: null,
				error: null
			},
			iconColor: 'blue darken-4',
			userProfile: {
				showDialog: false,
				data: {}
			}
		};
	},

	created() {
		this.imgFallback.loading = `${this.imgBase}loading.gif`;
		this.imgFallback.error = `${this.imgBase}user.png`;
	},

	methods: {
		show() {
			this.user.img = this.$refs.avatar.src;
			this.userProfile.showDialog = true;
		},
		dismiss(profile) {
			this.userProfile.showDialog = false;
			if (profile !== undefined) {
				this.user.name = profile.firstName + ' ' + profile.lastName;
				this.user.email = profile.email;
			}
		},
		logout() {
			this.$emit('logout');
			this.menu = false;
		}
	}
};
</script>
