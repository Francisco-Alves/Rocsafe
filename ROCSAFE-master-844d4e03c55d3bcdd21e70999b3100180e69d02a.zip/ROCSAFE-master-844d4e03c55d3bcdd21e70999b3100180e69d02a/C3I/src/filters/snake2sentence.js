/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import Vue from 'vue';

Vue.filter('snake2sentence', value => {
	if (!value) return '';
	let str = value.replace(/([a-zA-Z]+)_/g, '$1 ');
	str = str.replace(/\w\S*/g, txt => {
		return txt.charAt(0).toUpperCase() + txt.substr(1);
	});
	return str;
});
