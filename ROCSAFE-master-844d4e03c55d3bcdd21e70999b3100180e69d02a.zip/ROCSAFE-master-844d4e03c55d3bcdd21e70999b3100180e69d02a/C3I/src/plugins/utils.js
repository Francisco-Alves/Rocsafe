/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

export default {
	install: function (Vue) {
		Vue.prototype.$cloneObject = obj => JSON.parse(JSON.stringify(obj));

		Vue.prototype.$nullifyObject = obj => {
			Object.keys(obj).forEach(key => {
				if (Vue.prototype.$isObject(obj[key])) {
					Vue.prototype.$nullifyObject(obj[key]);
				} else {
					obj[key] = null;
				}
			});
		};
	}
};
