/* $Id$ */

var remoteVideo;
var peerConnection;
var serverConnection;
var uuid;

var peerConnectionConfig = {
	'iceServers': [{
		'urls': 'stun:stun.stunprotocol.org'
	}, {
		'urls': 'stun:stun1.l.google.com:19302'
	}, {
		'urls': 'stun:stun2.l.google.com:19302'
	}]
};

document.addEventListener('DOMContentLoaded', pageReady);

function pageReady() {
	uuid = getUuid();
	console.log('CLIENT: UUID:', uuid);
	remoteVideo = document.getElementById('remoteVideo');
	startServerConnection('wss://' + window.location.hostname + ':8443');
}

function startServerConnection(uri) {
	console.log('CLIENT: Starting signalling connection to:', uri);
	serverConnection = new WebSocket(uri);
	serverConnection.onmessage = gotMessageFromServer;
	serverConnection.onopen = function () {
		console.log('CLIENT: Signalling connection established');
		start();
	};
	serverConnection.onclose = function () {
		console.warn('CLIENT: Signaling connection was closed. Restarting in 5 seconds...');
		setTimeout(function () {
			startServerConnection(uri);
		}, 5000);
	};
}

function start() {
	peerConnection = new RTCPeerConnection(peerConnectionConfig);
	peerConnection.onicecandidate = gotIceCandidate;
	peerConnection.ontrack = gotRemoteStream;
	peerConnection.oniceconnectionstatechange = handleICEConnectionStateChangeEvent;
	peerConnection.createOffer({
		offerToReceiveAudio: true,
		offerToReceiveVideo: true
	}).then(createdDescription).catch(errorHandler);
	console.log('CLIENT: started peer connection', peerConnection);
}

function gotMessageFromServer(message) {
	if (!peerConnection) {
		start();
	}
	var signal = JSON.parse(message.data);
	// Ignore messages from ourself
	if (signal.uuid === uuid) {
		return;
	}
	console.log('CLIENT: got signalling message', signal);
	if (signal.sdp) {
		peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp)).catch(errorHandler);
	} else if (signal.ice) {
		peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice)).catch(errorHandler);
	}
}

function gotIceCandidate(event) {
	console.log('CLIENT: got ICE candidate', event);
	if (event.candidate !== null) {
		serverConnection.send(JSON.stringify({
			'ice': event.candidate,
			'uuid': uuid
		}));
	}
}

function createdDescription(description) {
	console.log('CLIENT: got description', description);
	peerConnection.setLocalDescription(description).then(function () {
		serverConnection.send(JSON.stringify({
			'sdp': peerConnection.localDescription,
			'uuid': uuid
		}));
	}).catch(errorHandler);
}

function gotRemoteStream(event) {
	console.log('CLIENT: got remote stream', event);
	remoteVideo.srcObject = event.streams[0];
}

function handleICEConnectionStateChangeEvent() {
	console.log('CLIENT: got ICE state change event:', peerConnection.iceConnectionState);
}

function errorHandler(error) {
	console.log('CLIENT: ' + error);
}

// Taken from http://stackoverflow.com/a/105074/515584
// Strictly speaking, it's not a real UUID, but it gets the job done here
function getUuid() {
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
	}
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}
