/* $Id$ */

var localVideo;
var localStream;
var peerConnection;
var serverConnection;
var uuid;

var peerConnectionConfig = {
	'iceServers': [{
		'urls': 'stun:stun.stunprotocol.org'
	}, {
		'urls': 'stun:stun1.l.google.com:19302'
	}, {
		'urls': 'stun:stun2.l.google.com:19302'
	}]
};

document.addEventListener('DOMContentLoaded', pageReady);

function pageReady() {
	uuid = getUuid();
	console.log('SERVER: UUID:', uuid);
	localVideo = document.getElementById('localVideo');
	startServerConnection('wss://' + window.location.hostname + ':8443');
	var constraints = {
		video: true,
		audio: true
	};
	if (navigator.mediaDevices.getUserMedia) {
		navigator.mediaDevices.getUserMedia(constraints).then(getUserMediaSuccess).catch(errorHandler);
	} else {
		alert('Your browser does not support getUserMedia API');
	}
}

function startServerConnection(uri) {
	console.log('SERVER: Starting signalling connection to:', uri);
	serverConnection = new WebSocket(uri);
	serverConnection.onmessage = gotMessageFromServer;
	serverConnection.onopen = function () {
		console.log('SERVER: Signalling connection established');
	};
	serverConnection.onclose = function () {
		console.warn('SERVER: Signaling connection was closed. Restarting in 5 seconds...');
		setTimeout(function () {
			startServerConnection(uri);
		}, 5000);
	};
}

function getUserMediaSuccess(stream) {
	console.log('SERVER: got user media', stream);
	localStream = stream;
	localVideo.srcObject = stream;
}

function start() {
	peerConnection = new RTCPeerConnection(peerConnectionConfig);
	peerConnection.onicecandidate = gotIceCandidate;
	peerConnection.oniceconnectionstatechange = handleICEConnectionStateChangeEvent;
	peerConnection.addStream(localStream);
	console.log('SERVER: started peer connection', peerConnection);
}

function gotMessageFromServer(message) {
	if (!peerConnection) {
		start();
	}
	var signal = JSON.parse(message.data);
	// Ignore messages from ourself
	if (signal.uuid === uuid) {
		return;
	}
	console.log('SERVER: got signalling message', signal);
	if (signal.sdp) {
		peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp)).then(function () {
			// Only create answers in response to offers
			if (signal.sdp.type === 'offer') {
				peerConnection.createAnswer().then(createdDescription).catch(errorHandler);
			}
		}).catch(errorHandler);
	} else if (signal.ice) {
		peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice)).catch(errorHandler);
	}
}

function gotIceCandidate(event) {
	console.log('SERVER: got ICE candidate', event);
	if (event.candidate !== null) {
		serverConnection.send(JSON.stringify({
			'ice': event.candidate,
			'uuid': uuid
		}));
	}
}

function createdDescription(description) {
	console.log('SERVER: got description', description);
	peerConnection.setLocalDescription(description).then(function () {
		serverConnection.send(JSON.stringify({
			'sdp': peerConnection.localDescription,
			'uuid': uuid
		}));
	}).catch(errorHandler);
}

function handleICEConnectionStateChangeEvent() {
	console.log('SERVER: got ICE state change event:', peerConnection.iceConnectionState);
}

function errorHandler(error) {
	console.log('SERVER: ' + error);
}

// Taken from http://stackoverflow.com/a/105074/515584
// Strictly speaking, it's not a real UUID, but it gets the job done here
function getUuid() {
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
	}
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}
