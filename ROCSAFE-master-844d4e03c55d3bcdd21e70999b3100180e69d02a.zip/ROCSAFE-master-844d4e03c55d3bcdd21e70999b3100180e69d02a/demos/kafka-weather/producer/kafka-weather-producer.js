#!/bin/sh
// eslint-disable-next-line semi
':' //# comment; exec /usr/bin/env node --noharmony '$0' '$@'

/*------------------------------------------------------------------------------
 * $Id::                                                                      $
 *------------------------------------------------------------------------------
 * Note: The lines to allow to run the code from the command line without
 * invoking node, must be the first lines in the file.  
 */

require('console-stamp')(console, 'yyyy-mm-dd HH:MM:ss.l');

var argv = require('yargs')
	.usage('Usage: $0 --lat=[lat] --lon=[lon]\nExample: $0 --lat=38.736946 --lon=-9.142685\n')
	.demandOption(['lat', 'lon'])
	.argv;

const settings = require('./settings'),
	OpenWeatherMap = require('openweathermap-node');

var KafkaRest = require('kafka-rest');

const weather = new OpenWeatherMap(settings.OpenWeatherMap);
var kafka = new KafkaRest({
	url: settings.kafka.url
});
var topic = kafka.topic('rocsafe.weather');

var weatherInfoSchema = new KafkaRest.AvroSchema({
	'type': 'record',
	'name': 'WeatherInfo',
	'namespace': 'rocsafe.inov',
	'doc': 'Schema for the rocsafe weather topics',
	'fields': [
		{
			'name': 'timestamp',
			'type': 'int',
			'doc': 'Time of data calculation, unix, UTC'
		},
		{
			'name': 'weather_id',
			'type': 'int',
			'doc': 'Weather condition id'
		},
		{
			'name': 'main',
			'type': 'string',
			'doc': 'Group of weather parameters (Rain, Snow, Extreme etc.'
		},
		{
			'name': 'description',
			'type': 'string',
			'doc': 'Weather condition within the group'
		},
		{
			'name': 'icon',
			'type': 'string',
			'doc': 'Weather icon id'
		},
		{
			'name': 'temp',
			'type': ['null', 'double'],
			'doc': 'Temperature in Celcius'
		},
		{
			'name': 'temp_min',
			'type': ['null', 'double'],
			'doc': 'Minimum temperature at the moment. This is deviation from current temp that is possible for large cities and megalopolises geographically expanded (use these parameter optionally).'
		},
		{
			'name': 'temp_max',
			'type': ['null', 'double'],
			'doc': 'Maximum temperature at the moment. This is deviation from current temp that is possible for large cities and megalopolises geographically expanded (use these parameter optionally). '
		},
		{
			'name': 'pressure',
			'type': ['null', 'double'],
			'doc': 'Atmospheric pressure (on the sea level, if there is no sea_level or grnd_level data), hPa'
		},
		{
			'name': 'humidity',
			'type': ['null', 'double'],
			'doc': 'Humidity, %'
		},
		{
			'name': 'visibility',
			'type': ['null', 'int'],
			'doc': 'Visibility, meter'
		},
		{
			'name': 'wind_speed',
			'type': ['null', 'double'],
			'doc': 'Wind speed, m/s'
		},
		{
			'name': 'wind_dir',
			'type': ['null', 'int'],
			'doc': 'Wind direction, degrees (meteorological)'
		},
		{
			'name': 'name',
			'type': 'string',
			'doc': 'City or area name'
		}
	]
});

const KELVIN_ABS = -273.15;

var getWeatherByGeoCoordinates = function (lat, lon) {
	return new Promise(function (resolve, reject) {
		weather.getCurrentWeatherByGeoCoordinates(lat, lon, (err, cw) => {
			if (err) {
				reject({
					action: 'getWeatherByGeoCoordinates: openweathermap.getCurrentWeatherByGeoCoordinates',
					report: err
				});
			} else {
				var data = {
					timestamp: cw.dt,
					weather_id: cw.weather[0].id,
					main: cw.weather[0].main,
					description: cw.weather[0].description,
					icon: cw.weather[0].icon
				};
				if (cw.main) {
					if (cw.main.temp) data.temp = {
						'double': ((10 * (cw.main.temp + KELVIN_ABS)) | 0) / 10
					};
					if (cw.main.temp_min) data.temp_min = {
						'double': ((10 * (cw.main.temp_min + KELVIN_ABS)) | 0) / 10
					};
					if (cw.main.temp_max) data.temp_max = {
						'double': ((10 * (cw.main.temp_max + KELVIN_ABS)) | 0) / 10
					};
					if (cw.main.pressure) data.pressure = {
						'double': cw.main.pressure
					};
					if (cw.main.humidity) data.humidity = {
						'double': cw.main.humidity
					};
				}
				if (cw.visibility) data.visibility = {
					'int': cw.visibility
				};
				if (cw.wind) {
					if (cw.wind.speed) data.wind_speed = {
						'double': cw.wind.speed
					};
					if (cw.wind.deg) data.wind_dir = {
						'int': cw.wind.deg
					};
				}
				if (cw.name) data.name = cw.name;

				topic.produce(weatherInfoSchema, data, function (err, res) {
					if (err) {
						reject({
							action: 'getWeatherByGeoCoordinates: kafka.topic.produce',
							report: err
						});
					}
					resolve({
						data: data,
						kafka: res
					});
				});
			}
		});
	});
};


getWeatherByGeoCoordinates(argv.lat, argv.lon).then(function (res) {
	console.log('Inserted weather report in kafka', res);
}).catch(function (err) {
	console.log('Error producing weather report', err);
});
