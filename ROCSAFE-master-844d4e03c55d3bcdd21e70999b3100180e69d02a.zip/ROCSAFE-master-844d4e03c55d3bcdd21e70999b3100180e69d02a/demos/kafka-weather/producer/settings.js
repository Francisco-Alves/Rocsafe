/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

module.exports = {
	app: {
		name: 'ROCSafe Weather Producer'
	},
	kafka: {
		url: 'http://localhost:8082'
	},
	OpenWeatherMap: {
		APPID: '7139f2e7858c58f6257a9b4c4acf33a9',	// Key Martijn
		units: 'metric'
	}
};
