/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

require('console-stamp')(console, 'yyyy-mm-dd HH:MM:ss.l');

var express = require('express'),
	session = require('express-session'),
	connectMongo = require('connect-mongo')(session),
	bodyParser = require('body-parser'),
	favicon = require('serve-favicon'),
	path = require('path'),
	settings = require('./settings'),
	mongoose = require('mongoose'),
	beautifulValidation = require('mongoose-beautiful-unique-validation'),
	Keycloak = require('keycloak-connect'),
	app = express();

mongoose.plugin(beautifulValidation);	

app.use(function (req, res, next) {
	if ((req.method === 'POST') || (req.method === 'PUT') || (req.method === 'DELETE')) {
		console.log('API - %s - %s %s', req.ip, req.method, req.path);
	}

	res.on('finish', function () {
		if ((res.statusCode >= 200) && (res.statusCode < 300)) {
			console.log('Done');
		} else if ((res.statusCode >= 400) && (res.statusCode < 500)) {
			console.log('Not ok: ' + res.statusCode);
		} else if (res.statusCode >= 500) {
			console.log('Server error: ' + res.statusCode);
		}
	});
	next();
});

//TODO: When the connection to the database is lost it does not automatically reconnect
mongoose.connect(settings.getUri(), {
	//	useMongoClient: true,	// Needed for older versions of mongoose
	socketTimeoutMS: 0,
	connectTimeoutMS: 0,
	family: settings.db.family || 4
});

console.log(settings.getUri());
//mongoose.set('debug', true);

var db = mongoose.connection;

db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
	console.log('Connected to DB');
	app.db = db;
});

app.use(bodyParser.urlencoded({
	extended: true
}));

// Create a session-store to be used by both the express-session
// middleware and the keycloak middleware.
const mongoStore = new connectMongo({
	mongooseConnection: db
});

app.use(session({
	secret: 'mySecret',
	resave: false,
	saveUninitialized: true,
	store: mongoStore
}));

// Provide the session store to the Keycloak so that sessions
// can be invalidated from the Keycloak console callback.
//
// Additional configuration is read from keycloak.json file
// installed from the Keycloak web console.

var keycloak = new Keycloak({
	store: mongoStore
}, path.join(__dirname, '/keycloak.json'));

app.keycloak = keycloak;
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use(favicon(path.join(__dirname, '../public/favicon.ico')));

// Install the Keycloak middleware.
//
// Specifies that the user-accessible application URL to
// logout should be mounted at /logout
//
// Specifies that Keycloak console callbacks should target the
// root URL.  Various permutations, such as /k_logout will ultimately
// be appended to the admin URL.
app.use(keycloak.middleware({
	logout: '/logout'
}));


// Routes
require('./routes/missions')(app);

// Start service
app.listen(settings.http.port, settings.http.host);
console.log(settings.app.name + ' listening on port ' + settings.http.port + '...');
