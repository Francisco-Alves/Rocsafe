/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

module.exports = {
	app: {
		name: 'ROCSAFE Server'
	},
	db: {
		host: 'st-db.inov.pt',
		port: 27017,
		name: 'rocsafe_test',
		user: null,
		password: null
	},
	http: {
		host: 'localhost',
		port: 8081
	},
	/* No parameters below this line */
	getUri: function () {
		return 'mongodb://' + ((this.db.user !== null) ? (this.db.user + ':' + this.db.password) : '') +
			this.db.host + '/' + this.db.name;
	}
};
