# JAVA API DEMO FOR KEYCLOAK

## Contents

This demo is a Java API built as Maven project. The demo contains: 
* JSON mapper. (Jackson v2.9.2)
* API errors and exception handlers build by Spring v5.0.1.RELEASE (WEB, MVC, CONTEXT)
* Logging to external file (Log4j2 v2.5) 
* Keycloak Spring adapter

## Requirements 

* Java 1.8 SDK 
* Tomcat 8.x.x 
* Keycloak Installed and configured
	
## MORE INFO

* [Keycloak Docs](http://www.keycloak.org/docs/latest/getting_started/index.html)
* [Tomcat Configuration](http://www.keycloak.org/docs/latest/securing_apps/index.html#_tomcat_adapter)
* [Keycloak Java Spring Security](http://www.keycloak.org/docs/latest/securing_apps/index.html#_spring_security_adapter)