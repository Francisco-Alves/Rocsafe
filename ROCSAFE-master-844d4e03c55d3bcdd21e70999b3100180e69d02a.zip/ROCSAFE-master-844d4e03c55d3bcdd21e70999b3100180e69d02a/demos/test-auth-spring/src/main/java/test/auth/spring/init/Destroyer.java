package test.auth.spring.init;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Destroyer implements ServletContextListener {

	final static Logger log = LogManager.getLogger(Destroyer.class);
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		
		log.info("Shutting down test-auth-spring app");
		log.info("=============================");
	}
	@Override
	public void contextInitialized(ServletContextEvent arg0) {	}
}
