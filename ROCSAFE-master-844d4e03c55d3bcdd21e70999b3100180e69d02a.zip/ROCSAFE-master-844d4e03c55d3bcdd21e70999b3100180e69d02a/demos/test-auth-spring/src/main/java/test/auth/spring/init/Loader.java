package test.auth.spring.init;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.WebApplicationInitializer;

public class Loader implements WebApplicationInitializer{

	private static final Logger log = LogManager.getLogger(Loader.class);
	static final String SERVER_HOST_NAME =  "rocsafe.inov.pt";
	static final String LOCAL_HOST_IP = "10.154.2.213"; // my local IP 
	static final String LOCAL_KEYCLOAK_JSON_FILE_PATH="/WEB-INF/keycloak-local.json";
	static final String SERVER_KEYCLOAK_JSON_FILE_PATH="/WEB-INF/server.json";
	static final String REAL_KEYCLOAK_JSON_FILE_PATH="/WEB-INF/keycloak.json";
	
	@Override
	public void onStartup(ServletContext context) throws ServletException  {
		/**
		 * The Idea here is the check the hosting machine IP, 
		 * If the hosting machine has my IP, Thats means the app is working on local.
		 * If the hosting machine has another IP, thats means the app is working on Server. 
		 * The app should select he corresponding Keycloak JSON file. 
		 * 
		 */
		log.info("Starting test-auth-spring app");
		String acualHostIP= "";
		try {
			acualHostIP = InetAddress.getLocalHost().getHostAddress();
			log.info("Hostname is : "+ acualHostIP);
			if(LOCAL_HOST_IP.equals(acualHostIP)) {
				//String jsonFileAsString= readJsonFile(LOCAL_KEYCLOAK_JSON_FILE_PATH,context);
				//createJsonFile(jsonFileAsString,context);
				log.info("Using local Keycloak JSON file");
			}else {
				//String jsonFileAsString = readJsonFile(SERVER_KEYCLOAK_JSON_FILE_PATH, context);
				//createJsonFile(jsonFileAsString,context);
				log.info("Using server Keycloak JSON File");
			}
		}catch(UnknownHostException ex) {
			String msg = "Can not get the actual HostIP.";
			log.warn(msg); 
			throw new RuntimeException(msg);
		}
		log.info("=============================");
		// Add the destroyer overwrite Listener; 
		context.addListener(new Destroyer());
	}
	private String readJsonFile(String path, ServletContext context) {
		String file = "";
		try {
			InputStream inputStream = context.getResourceAsStream(LOCAL_KEYCLOAK_JSON_FILE_PATH);
			BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
			file =  br.lines().collect(Collectors.joining(System.lineSeparator()));
		}catch(Exception  ex) {
			String msg ="Can't read Keycloak JSON file! " ;
			log.warn(msg);
			throw new RuntimeException(ex.getMessage());	
		}
		return file;
	}
	
	private void createJsonFile(String jsonInput, ServletContext context) {
		try {
			FileWriter JF = new FileWriter(context.getRealPath(REAL_KEYCLOAK_JSON_FILE_PATH));
			BufferedWriter bufferWriter = new BufferedWriter(JF);
			bufferWriter.write(jsonInput);
			bufferWriter.close();
		} catch (IOException ex) {
			String msg ="Can't create keycloak JOSN file.";
			log.warn(msg);
			throw new RuntimeException(ex.getMessage());
		}
	}
	
}
