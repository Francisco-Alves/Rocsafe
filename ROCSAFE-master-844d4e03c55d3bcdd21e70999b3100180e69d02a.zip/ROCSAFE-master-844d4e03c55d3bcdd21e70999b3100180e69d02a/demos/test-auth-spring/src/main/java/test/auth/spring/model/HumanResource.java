/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
package test.auth.spring.model;

public class HumanResource {

	// --------------------------------------------------------------------------
	// Properties
	// --------------------------------------------------------------------------
	public String id;
	public String firstName; 
	public String lastName; 
	public String gender; 
	public String email; 
	public String phone; 
	
	// --------------------------------------------------------------------------
	// Constructors
	// --------------------------------------------------------------------------

	/**
	 * General Constructor
	 */
	public HumanResource() {
	}

	public HumanResource(String id) {
		this.id = id;
	}
	/**
	 * Full constructor
	 * 
	 * @param id
	 * @param desc
	 */
	public HumanResource(String id, String name, String last, String gender, String email, String phone) {
		this.id = id; 
		this.firstName = name; 
		this.lastName = last; 
		this.gender = gender;
		this.email = email; 
		this.phone  = phone; 
	}
}
