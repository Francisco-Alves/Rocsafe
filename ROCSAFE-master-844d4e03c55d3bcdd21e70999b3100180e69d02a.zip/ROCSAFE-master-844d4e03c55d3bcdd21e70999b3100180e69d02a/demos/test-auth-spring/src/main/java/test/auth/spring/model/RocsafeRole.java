package test.auth.spring.model;

public enum RocsafeRole { 
	MISSION_COMMANDER, // attribute ==> ms_missions
	CRIME_SCENE_MANAGER, // attribute ==> csm_missions
	SENIOR_CRIME_INFISTIGATOR, // attribute ==> sci_missions
	STADARD_USER, // attribute ==> su_missions
	SYSTEM_ADMINISTRATOR // attribute ==> sa_missions
} 

