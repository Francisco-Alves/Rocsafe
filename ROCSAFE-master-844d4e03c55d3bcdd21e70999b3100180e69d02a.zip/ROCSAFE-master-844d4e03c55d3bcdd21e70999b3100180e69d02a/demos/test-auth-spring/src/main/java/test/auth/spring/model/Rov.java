/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
package test.auth.spring.model;

import java.util.ArrayList;

public class Rov {

	// --------------------------------------------------------------------------
	// Properties
	// --------------------------------------------------------------------------
	//id of ROV
	public String id;
	// name of device
	public String name;
	// description of device.
	public String desc;
	// type of the ROV can be any of the following values: “RAV”, “RGV”, “RGV-LP” or “OC”.
	public  RovType type;
	// Array of sensors ids
	public ArrayList<Sensor> sensors; 
	

	// --------------------------------------------------------------------------
	// Constructors
	// --------------------------------------------------------------------------

	/**
	 * General Constructor
	 */
	public Rov() {
	}
	
	public Rov(String id) {
		this.id = id ;		
	}
	
	public Rov(String id, String name) {
		this.id = id ; 
		this.name = name;
	}
	/**
	 * Full Constructor
	 * 
	 * @param id
	 * @param desc
	 */
	public Rov(String id, String name, String desc) {
		this.id = id; 
		this.name= name; 
		this.desc = desc;
	}
	
	public Rov(String id, String name, String desc, RovType type, ArrayList<Sensor> sensors) {
		this.id= id ; 
		this.name= name ; 
		this.desc = desc; 
		this.type = type;
		this.sensors= sensors;
	}

	// --------------------------------------------------------------------------
	// Methods
	// --------------------------------------------------------------------------
	
	
}
