package test.auth.spring.model;

public enum RovType {
	RAV, // 
	RGV,
	RGVLP,
	OC 
}
