package test.auth.spring.model;

import java.util.ArrayList;

public class Sensor {

	public int id; 
	public String name;  
	public ArrayList<Attribute> attributes;
	
}
