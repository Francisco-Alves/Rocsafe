/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
package test.auth.spring.rest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.filter.ServletContextRequestLoggingFilter;


/**
 * Super class of REST API Error Hanling
 */
public class API  {



	Logger log = LogManager.getLogger(API.class);
	
	//--------------------------------------------------------------------------
	// Error handling
	//--------------------------------------------------------------------------
	
	
	/**
	 * Maps HttpServerErrorException to the respective HTTP status
	 */
	@ExceptionHandler(value = HttpServerErrorException.class)
	@ResponseBody
	public ErrorResponse httpStatus(HttpServerErrorException e) {
		return new ErrorResponse(e.getMessage(), e.getStatusCode());
	}
	
	/**
	 * Maps InternalServerError to the respective HTTP status
	 */
	@ExceptionHandler(value = InternalServerError.class)
	@ResponseBody
	public ErrorResponse internalServerError(InternalServerError e) {
		
		return new ErrorResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/**
	 * Maps remaining exceptions to a BAD_REQUEST HTTP status
	 */
	@ExceptionHandler(value = Exception.class)
	@ResponseBody
	public ErrorResponse badRequest(Exception e) {
		//TODO? do not provide error details when in PRODUCTION
		return new ErrorResponse(e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	//--------------------------------------------------------------------------
	// Error handling helpers
	//--------------------------------------------------------------------------
	
	/** 
	 * Encapsulates error response
	 */
	public class ErrorResponse extends ResponseEntity<ErrorDetails> {
		public ErrorResponse(String message, HttpStatus statusCode) {
			super(new ErrorDetails(message), newHeaders(), statusCode);
		}
	}
	
	/** 
	 * Encapsulates error details sent in error response
	 */
	public class ErrorDetails {
		public String error;
		public ErrorDetails() { this(null); }
		public ErrorDetails(String message) { this.error = message == null ? "Description N/A" : message; }
	}
	
	/**
	 * @return new HttpHeaders (used in ErrorResponse)
	 */
	public static HttpHeaders newHeaders() {
		//Force content-type (required when an endpoint does not returns JSON)
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json;charset=utf-8");
		return headers;
	}

	 
}