/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
package test.auth.spring.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.module.afterburner.AfterburnerModule;
/**
 * JSON object mapper.
 * @author OMAR-INOV
 *
 */
public class JsonObjectMapper extends ObjectMapper {
	/**
	 * base mapper for REST For Rest APIs
	 */
	private static final long serialVersionUID = 1L;
	static final String DATE_SIMPLE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
 
	public JsonObjectMapper() {
		// speedup adding dynamic bytecode generation
		registerModule(new AfterburnerModule());
		// ISO 8601 dates
		configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		// do not serialize null fields
		setSerializationInclusion(JsonInclude.Include.NON_NULL);
	}
}
