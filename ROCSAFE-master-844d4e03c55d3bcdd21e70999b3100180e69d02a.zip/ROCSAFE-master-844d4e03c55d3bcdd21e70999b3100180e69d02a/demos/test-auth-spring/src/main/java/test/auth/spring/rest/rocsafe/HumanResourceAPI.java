/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                       $
 *----------------------------------------------------------------------------*/
package test.auth.spring.rest.rocsafe;

import java.util.Collection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import test.auth.spring.model.HumanResource;
import test.auth.spring.rest.API;
import test.auth.spring.services.HresService;

@RestController
@RequestMapping
public class HumanResourceAPI extends API{
	 
	Logger log = LogManager.getLogger(HumanResourceAPI.class);
	
	@Autowired
	HresService hresSvc;
	
	/**
	 * List Summary of all Human Resource
	 * @return
	 */
	@GetMapping("/v{version}/hres/")
	public Collection<HumanResource> getAgents(@PathVariable("version") int version){
		return this.hresSvc.getHresList();
	}
	
	/**
	 * Create a new Human Resource
	 * @param HumanResource
	 * @return
	 */
	@PostMapping(path="/v{version}/hres/")
	public HumanResource createAgent(@RequestBody HumanResource hresBody) {
		return this.hresSvc.createHres(hresBody);
	}
	
	/**
	 * List detailed infor for an Human Resource.
	 * @param id
	 * @return
	 */
	@GetMapping("/v{version}/hres/{hre_id}")
	public HumanResource getAgentDetails(@PathVariable("hre_id") String id) {
		return this.hresSvc.getHresObject(id);
	}
	
	/**
	 * update Human Resource info
	 * @param HumanResource
	 * @return
	 */
	@PutMapping(path="/v{version}/hres/{hre_id}")
	public HumanResource updateAgent(@RequestBody HumanResource hresBody, @PathVariable("hre_id") String id ) {
		return this.updateAgent(hresBody, id);
	}
	
	/**
	 * detete a Human Resource
	 * @param id
	 * @return
	 */
	@DeleteMapping(path="/v{version}/hres/{hre_id}")
	public HumanResource deteteRov(@PathVariable("hre_id") String id) {
		
		return this.hresSvc.deleteHres(id);
	}
	
	
}
