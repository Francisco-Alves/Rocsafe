/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                       $
 *----------------------------------------------------------------------------*/
package test.auth.spring.rest.rocsafe;

import java.util.Collection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import test.auth.spring.model.Rov;
import test.auth.spring.rest.API;
import test.auth.spring.services.RovsService;

/**
 * Mission API endpoints
 * 
 * @author OMAR-INOV
 *
 */
@RestController
@RequestMapping
public class RovAPI extends API {
	
	Logger log = LogManager.getLogger(RovAPI.class);
	
	@Autowired
	RovsService RovSvc;
	
	/**
	 * Lists summary info for all ROVs
	 * 
	 * @return
	 */
	@GetMapping("/v{version}/rovs/")
	public Collection<Rov> getRovs() {
		log.info("Get List of ROVS.");
		return RovSvc.getRovsList();
	}

	/**
	 * List detailed info for ROV
	 * 
	 * @param id
	 */
	@GetMapping("/v{version}/rovs/{rov_id}")
	public Rov getRovDetails(@PathVariable("rov_id") String id) {
		log.info("Get an ROV object");
		return RovSvc.getRov(id);
	}

	/**
	 * Creates a new ROV
	 * 
	 * @param rovBody
	 */
	@PostMapping(path = "/v{version}/rovs/")
	public Rov createRov(@RequestBody Rov rovBody) {
		log.info("Create new ROV ");
		return this.RovSvc.createRov(rovBody);
	}

	/**
	 * Update a ROV
	 * 
	 * @param rovBody
	 * @return
	 */
	@PutMapping(path = "/v{version}/rovs/{rov_id}")
	public Rov updateRov(@RequestBody Rov rovBody, @PathVariable("rov_id") String id) {
		log.info("Update a ROV ");
		return this.RovSvc.updateRov(id, rovBody);
	}

	/**
	 * Delete a ROV
	 * 
	 * @param id
	 * @return
	 */
	@DeleteMapping(path = "/v{version}/rovs/{rov_id}")
	public Rov deleteRov(@PathVariable("rov_id") String id) {
		log.info("Delete a ROV Object");
		return this.RovSvc.deleteRov(id);
	}

}
