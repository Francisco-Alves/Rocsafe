package test.auth.spring.rest.rocsafe;
import test.auth.spring.model.Version;
import test.auth.spring.rest.API;
 

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

@RestController
@RequestMapping
public class VersionAPI  extends API{
	/**
	 * Lists summaries of missions
	 * 
	 * @return
	 */
	@GetMapping("/v{version}/")
	public Version getApiVersion(@PathVariable("version") int version) {
		Version apiInfo = new Version();
		apiInfo.name="ROCSAFE";
		apiInfo.version="v"+ version; 
		return apiInfo;
	}
	
}
