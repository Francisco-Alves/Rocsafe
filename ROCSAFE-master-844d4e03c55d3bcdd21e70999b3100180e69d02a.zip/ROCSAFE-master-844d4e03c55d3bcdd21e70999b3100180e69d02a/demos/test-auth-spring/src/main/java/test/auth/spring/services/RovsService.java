package test.auth.spring.services;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import test.auth.spring.model.Rov;
import test.auth.spring.model.RovType;
import test.auth.spring.rest.rocsafe.RovAPI;

@Service
public class RovsService  {
	
	Logger log = LogManager.getLogger(RovAPI.class);

	ArrayList<Rov> Rovs; 
	
	public RovsService() {
		setRovsList();
	}

	private void setRovsList() {
		this.Rovs = new ArrayList<Rov>();
		this.Rovs.add(new Rov("001","Rov001", "Machine for collecting somthing", RovType.RAV , null));
		this.Rovs.add(new Rov("002","Rov002", "Machine for collecting somthing", RovType.RGV , null));
		this.Rovs.add(new Rov("003","Rov003", "Machine for collecting somthing", RovType.RGVLP , null));
		this.Rovs.add(new Rov("004","Rov004", "Machine for collecting somthing", RovType.OC , null));
		this.Rovs.add(new Rov("005","Rov005", "Machine for collecting somthing", RovType.RGV , null));
		this.Rovs.add(new Rov("006","Rov006", "Machine for collecting somthing", RovType.OC , null));
		this.Rovs.add(new Rov("007","Rov001", "Machine for collecting somthing", RovType.RAV , null));
		this.Rovs.add(new Rov("008","Rov002", "Machine for collecting somthing", RovType.RGV , null));
		this.Rovs.add(new Rov("009","Rov003", "Machine for collecting somthing", RovType.RGVLP , null));
		this.Rovs.add(new Rov("010","Rov004", "Machine for collecting somthing", RovType.OC , null));
		this.Rovs.add(new Rov("011","Rov005", "Machine for collecting somthing", RovType.RGV , null));
		this.Rovs.add(new Rov("012","Rov006", "Machine for collecting somthing", RovType.OC , null));
	}

	// --------------------------------------------------------------------------
	// Methods
	// --------------------------------------------------------------------------
	
	public Rov getRov(String id) {
		for( Rov r : this.Rovs) {
			if(r.id.equals(id)) {
				return r;
			}
		}
		return new Rov("N/A", "ROV Not found");
	}
	
	public ArrayList<Rov> getRovsList() {
		return this.Rovs;
	}
	
	public Rov updateRov(String id, Rov rovObject) {
		Rov r = getRov(id);
		if(r.id.equals("N/A")) {
			return r; 
		}
		r.name = rovObject.name;
		r.desc = rovObject.desc;
		r.type = rovObject.type;
		r.sensors = rovObject.sensors;
		return r;
	}
	
	public Rov deleteRov(String id) {
		Rov r = getRov(id);
		if(r.id.equals("N/A")) {
			return r;
		}
		Rov rCopy = new Rov(r.id, r.name, r.desc, r.type, r.sensors);
		this.Rovs.remove(r);
		return rCopy;
	}
	
	public Rov createRov(Rov rovObject) {
		this.Rovs.add(rovObject);
		return rovObject;
	}
}
