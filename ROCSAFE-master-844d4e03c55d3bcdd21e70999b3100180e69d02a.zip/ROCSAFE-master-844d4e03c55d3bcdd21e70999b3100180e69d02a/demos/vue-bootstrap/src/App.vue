<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<div id="app">
		<a href="https://vuejs.org" target="_blank">
			<img v-b-tooltip.left :height="logoH" src="./assets/vue-logo.png" title="Vue.js - The Progressive JavaScript Framework">
		</a>
		<a href="https://bootstrap-vue.js.org" target="_blank">
			<img v-b-tooltip.right :height="logoH" src="./assets/vue-bootstrap-logo.png" title="BootstrapVue - Quickly integrate Bootstrap 4 Components with Vue.js">
		</a>
		<h3>{{ msg }}</h3>
		<b-container>
			<b-row class="justify-content-md-center" align-v="center">
				<b-col md="3">
					<b-button variant="success" @click="alert('Success')">Success</b-button>
				</b-col>
				<b-col md="auto" class="my-2">
					<b-form-select v-model="player" :options="options">
						<template slot="first">
							<option :value="null" disabled>-- Select a player --</option>
						</template>
					</b-form-select>
				</b-col>
				<b-col md="3">
					<b-button variant="danger" @click="alert('Danger')">Danger</b-button>
				</b-col>
			</b-row>
		</b-container>
		<p v-if="player" class="mt-2">You have selected player <b>{{ player.name }}</b> that carries jersey number <b>{{ player.number }}</b></p>
		<b-modal ref="myModalRef" :title="modalMsgType" :header-bg-variant="modalBgVariant" centered size="sm" ok-only no-close-on-esc no-close-on-backdrop header-text-variant="light">
			You have pressed the
			<br><strong>{{ modalMsgType }}</strong> button!
		</b-modal>
	</div>
</template>

<script>
export default {
	name: 'App',
	data() {
		return {
			msg: 'Vue.js & Bootstrap-Vue Demo App',
			options: [
				{
					value: {
						number: 28,
						name: 'Bas Dost'
					},
					text: 'Bas Dost'
				},
				{
					value: {
						number: 77,
						name: 'Gelson Martins'
					},
					text: 'Gelson Martins'
				},
				{
					value: {
						number: 8,
						name: 'Bruno Fernandes'
					},
					text: 'Bruno Fernandes'
				},
				{
					value: {
						number: 4,
						name: 'Sebastián Coates'
					},
					text: 'Sebastián Coates'
				},
				{
					value: {
						number: 1,
						name: 'Rui Patrício'
					},
					text: 'Rui Patrício'
				}
			],
			player: null,
			logoH: 80,
			modalMsgType: null,
			modalBgVariant: null
		};
	},
	methods: {
		alert(msgType) {
			this.modalMsgType = msgType;
			this.modalBgVariant = msgType.toLowerCase();
			this.$refs.myModalRef.show();
			console.log('You have pressed the ' + msgType + ' button.');
		}
	}
};
</script>

<style>
#app {
	font-family: 'Avenir', Helvetica, Arial, sans-serif;
	text-align: center;
	margin-top: 20px;
}
h1,
h2 {
	font-weight: normal;
}
img {
	margin: 0 10px;
}
</style>
