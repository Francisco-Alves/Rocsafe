/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import Vue from 'vue';

import {
	Button,
	FormSelect,
	Layout,
	Modal,
	Tooltip
} from 'bootstrap-vue/es/components';
import vBTooltip from 'bootstrap-vue/es/directives/tooltip/tooltip';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-vue/dist/bootstrap-vue.css';

import App from './App.vue';

Vue.use(Button);
Vue.use(FormSelect);
Vue.use(Layout);
Vue.use(Modal);
Vue.use(Tooltip);

Vue.directive('b-tooltip', vBTooltip);

new Vue({
	el: '#app',
	render: h => h(App)
});
