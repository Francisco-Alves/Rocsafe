# vue-element

> Vue.js & Element Demo App

## Build Setup

``` bash
# Install dependencies
npm install

# Serve with hot reload at localhost. It will run on port 8080 by default.
# If that port is already in use, the next free port will be used.
npm run dev

# Build for production with minification
npm run build

# Deploy bundled package to production server
npm run deploy

# Lint source code
npm run lint

# Clean both development and build folders
npm run clean
```

For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).
