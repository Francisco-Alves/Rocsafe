/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

new Vue({
	el: '#app',
	data: {
		logoW: null,
		winLayout: {
			w: null,
			h: null,
			x: null,
			y: null
		},
		zoom: null,
		winId: null,
		childWin: []
	},
	created: function () {
		console.log('Vue: Created');
		this.isChrome = !!window.chrome && !!window.chrome.webstore;
		console.log('Chrome:', this.isChrome ? 'Yes' : 'No');
		this.winBaseName = 'vue-multi-window-';
		if (window.name.indexOf(this.winBaseName) !== 0) {
			/* Main Window */
			this.winId = 0;
			this.logoW = 160;
		} else {
			/* Child Windows */
			this.winId = window.name.slice(this.winBaseName.length);
			this.logoW = 80;
		}
		this.winName = this.winBaseName + this.winId;
		localStorage.setItem(this.winName, true);
		this.handleWindowResize({
			target: window
		});
		this.handleWindowPosition();
		window.addEventListener('resize', this.handleWindowResize);
		this.interval = setInterval(this.handleWindowPosition, 250);
		window.addEventListener('beforeunload', this.handleWindowBeforeunload);
	},
	mounted: function () {
		console.log('Vue: Mounted');
		if (this.winId === 0) {
			this.restoreWindows();
		} else {
			this.adjustWindow();
		}
	},
	beforeDestroy: function () {
		console.log('Vue: Before Destroy');
		window.removeEventListener('resize', this.handleWindowResize);
		clearInterval(this.interval);
	},
	methods: {
		handleWindowResize: function (event) {
			this.winLayout.w = event.target.innerWidth;
			this.winLayout.h = event.target.innerHeight;
			this.zoom = Math.round(event.target.devicePixelRatio * 100);
		},
		handleWindowPosition: function () {
			this.winLayout.x = window.screenX;
			this.winLayout.y = window.screenY;
		},
		launchWindow: function (event, layout) {
			console.log('Launch Window: Layout:', layout);
			var l;
			var pr = window.devicePixelRatio;
			if (layout === undefined) {
				l = {
					w: 250,
					h: 250,
				};
				if (this.isChrome) {
					l.x = this.winLayout.x + Math.round((window.outerWidth - (l.w * pr)) / 2);
					l.y = this.winLayout.y + Math.round((window.outerHeight - (l.h * pr)) / 2);
				} else {
					l.x = this.winLayout.x + Math.round((window.outerWidth - l.w) / 2);
					l.y = this.winLayout.y + Math.round((window.outerHeight - l.h) / 2);
				}
			} else {
				l = layout;
			}
			var name = this.winBaseName + (this.childWin.length + 1);
			var win;
			if (l !== null) {
				var params;
				if (this.isChrome) {
					params = 'width=' + Math.round(l.w * pr) + ',height=' + Math.round(l.h * pr) +
						',left=' + l.x + ',top=' + l.y;
				} else {
					params = 'width=' + l.w + ',height=' + l.h + ',left=' + l.x + ',top=' + l.y;
				}
				params += ',menubar=no,toolbar=no,location=no,personalbar=no,status=no,resizable=yes,scrollbars=yes';
				console.log('Window Params:', params);
				win = window.open(location.href, name, params);
				if (win !== null) {
					win.addEventListener('beforeunload', this.updateChildWin);
					this.childWin.push(win);
				}
			} else {
				this.childWin.push(null);
			}
		},
		restoreWindows: function () {
			var maxChild = localStorage.getItem(this.winName + ':maxChild');
			console.log('Restore Windows: Stored Childs:', maxChild);
			if (maxChild === null) {
				return;
			}
			for (var i = 1; i <= maxChild; i++) {
				var layout = this.storageGet(this.winBaseName + i + ':layout');
				this.launchWindow(null, layout);
			}
		},
		adjustWindow: function () {
			var layout = this.storageGet(this.winName + ':layout');
			console.log('Adjust Window: Stored Layout:', layout);
			if (layout === null) {
				return;
			}
			var dx = layout.x - this.winLayout.x;
			var dy = layout.y - this.winLayout.y;
			if (dx !== 0 || dy !== 0) {
				console.log('Window Position Adjust: Dx=' + dx + ' Dy=' + dy);
				if (this.isChrome) {
					window.moveTo(layout.x + dx, layout.y + dy);
				} else {
					window.moveBy(dx, dy);
				}
			}
			var dw = layout.w - this.winLayout.w;
			var dh = layout.h - this.winLayout.h;
			if (dw !== 0 || dh !== 0) {
				console.log('Window Size Adjust: Dw=' + dw + ' Dh=' + dh);
				window.resizeBy(dw, dh);
			}
		},
		closeWindows: function () {
			console.log('Close Windows');
			for (var i = 0; i < this.childWin.length; i++) {
				if (this.childWin[i] !== null) {
					this.childWin[i].close();
				}
			}
		},
		updateChildWin: function (event) {
			var winName = event.currentTarget.name;
			console.log('Update Child Windows: Event source:', winName);
			var id = Number(winName.substring(this.winBaseName.length));
			if (id > 0) {
				this.childWin[id - 1] = null;
			}
			var i;
			for (i = this.childWin.length - 1; i >= 0; i--) {
				if (this.childWin[i] !== null) {
					return;
				}
			}
			for (i = this.childWin.length; i > 0; i--) {
				this.childWin.pop();
			}
		},
		handleWindowBeforeunload: function () {
			console.log('Handle Window Beforeunload:', this.winName);
			localStorage.removeItem(this.winName);
			if (this.winId === 0) {
				localStorage.setItem(this.winName + ':maxChild', this.childWin.length);
				this.closeWindows();
			}
			if (localStorage.getItem(this.winBaseName + 0) === null) {
				this.storageSet(this.winName + ':layout', this.winLayout);
			} else {
				this.storageRem(this.winName + ':layout');
			}
		},
		storageGet: function (key) {
			var val = localStorage.getItem(key);
			return JSON.parse(val);
		},
		storageSet: function (key, obj) {
			var val = JSON.stringify(obj);
			localStorage.setItem(key, val);
		},
		storageRem: function (key) {
			localStorage.removeItem(key);
		},
	}
});
