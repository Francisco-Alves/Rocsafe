/* $Id$ */

const hostname = 'localhost';
const port = 3000;

const fs = require('fs');
const http = require('http');
const WebSocket = require('ws');
const consoleStamp = require('console-stamp');

consoleStamp(console, 'yyyy-mm-dd HH:MM:ss.l');

// ----------------------------------------------------------------------------------------

// Create a server for HTTP requests
const handleRequest = function (request, response) {
	// Render the client/server html files for any request the HTTP server receives
	console.log(`HTTP - ${request.connection.remoteAddress} - ${request.method} ${request.url}`);

	if (request.method !== 'GET') {
		notFound(response);
		return;
	}

	switch (request.url) {
	case '/client':
		response.writeHead(200, {
			'Content-Type': 'text/html'
		});
		response.end(fs.readFileSync('client/client.html'));
		break;
	case '/server':
		response.writeHead(200, {
			'Content-Type': 'text/html'
		});
		response.end(fs.readFileSync('client/server.html'));
		break;
	case '/webrtc-client.js':
		response.writeHead(200, {
			'Content-Type': 'application/javascript'
		});
		response.end(fs.readFileSync('client/webrtc-client.js'));
		break;
	case '/webrtc-server.js':
		response.writeHead(200, {
			'Content-Type': 'application/javascript'
		});
		response.end(fs.readFileSync('client/webrtc-server.js'));
		break;
	case '/favicon.ico':
		try {
			var data = fs.readFileSync('/favicon.ico');
			response.writeHead(200, {
				'Content-Type': 'image/vnd.microsoft.icon'
			});
			response.end(data);
		} catch (err) {
			notFound(response);
		}
		break;
	default:
		notFound(response);
	}
};

const notFound = function (resp) {
	resp.statusCode = 404;
	resp.end('<h1>Not Found</h1>');
};

const httpServer = http.createServer(handleRequest);
httpServer.listen(port, hostname);

// ----------------------------------------------------------------------------------------

// Create a server for handling websocket requests
const ws = new WebSocket.Server({
	host: hostname,
	port: port + 1
});

ws.on('connection', function (conn) {
	conn.on('message', function (message) {
		// Broadcast any received message to all clients
		console.log(`WS: ${message}`);
		ws.broadcast(message);
	});
});

ws.broadcast = function (data) {
	this.clients.forEach(function (client) {
		if (client.readyState === WebSocket.OPEN) {
			client.send(data);
		}
	});
};

console.log('WebRTC signalling server running.' +
	'\nHostname:  ' + hostname +
	'\nHTTP Port: ' + port +
	'\nWS Port:   ' + (port + 1) +
	'\n');
