<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-layout row justify-center>
		<v-dialog v-model="show" persistent scrollable max-width="600px">
			<v-card>
				<v-card-title>
					<v-toolbar dense dark color="primary">
						<v-avatar size="40">
							<img :src="avatar" alt="Avatar">
						</v-avatar>
						<span class="headline mx-3">User Profile</span>
						<v-spacer></v-spacer>
						<v-btn icon dark @click.native="$emit('dismiss')">
							<v-icon>close</v-icon>
						</v-btn>
					</v-toolbar>
				</v-card-title>
				<v-card-text>
					<v-container v-if="loading" fill-height>
						<v-layout align-center>
							<v-flex class="text-xs-center">
								<v-progress-circular :size="60" :width="6" indeterminate color="amber"></v-progress-circular>
							</v-flex>
						</v-layout>
					</v-container>
					<v-container v-else grid-list-md>
						<v-form ref="form" v-model="valid">
							<v-layout wrap>
								<v-flex xs12 sm6>
									<v-text-field v-model="profile.username" label="Username" readonly></v-text-field>
								</v-flex>
								<v-flex xs12 sm6>
									<v-text-field v-model="profile.email" :rules="[rules.required, rules.email]" label="Email" required></v-text-field>
								</v-flex>
								<v-flex xs12 sm6>
									<v-text-field v-model="profile.firstName" :rules="[rules.required]" label="First Name" required></v-text-field>
								</v-flex>
								<v-flex xs12 sm6>
									<v-text-field v-model="profile.lastName" :rules="[rules.required]" label="Last Name" required></v-text-field>
								</v-flex>
								<v-flex v-for="(value, key) in profile.attributes" :key="key" xs12 sm6>
									<v-select v-if="key === 'country'" :items="countries" v-model="profile.attributes.country[0]" label="Country" placeholder="Select..."></v-select>
									<v-text-field v-else :label="key | capitalize | camel2sentence" v-model="profile.attributes[key][0]"></v-text-field>
								</v-flex>
							</v-layout>
						</v-form>
					</v-container>
				</v-card-text>
				<v-card-actions class="pa-3">
					<v-spacer></v-spacer>
					<v-btn :disabled="!valid || loading" :loading="saving" color="primary" @click.native="save">
						Save
						<v-icon right>backup</v-icon>
					</v-btn>
				</v-card-actions>
			</v-card>
		</v-dialog>
	</v-layout>
</template>

<script>
export default {
	props: {
		'show': {
			type: Boolean,
			required: true
		},
		'avatar': {
			type: String,
			default: null
		}
	},

	data() {
		return {
			profile: {},
			valid: false,
			loading: false,
			saving: false,
			countries: ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czech Republic', 'Denmark', 'Estonia', 'Finland',
				'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia', 'Lithuania', 'Luxembourg', 'Malta',
				'Netherlands', 'Poland', 'Portugal', 'Romania', 'Slovakia', 'Slovenia', 'Spain', 'Sweden', 'United Kingdom'],
			rules: {
				required: value => value !== undefined && value.trim().length > 0 || 'Required',
				email: value => /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(value) || 'E-mail must be valid'
			}
		};
	},

	watch: {
		show(value) {
			if (!value) {
				return;
			}
			console.log('GET');
			this.loading = true;
			this.$http.get(this.uri)
				.then(response => {
					console.log('GET RESP', response.data);
					this.loading = false;
					this.profile = response.data;
					this.$nextTick(() => this.$refs.form.validate());
				})
				.catch(error => {
					this.loading = false;
					this.errorHandler(error);
				});
		}
	},

	created() {
		this.uri = '/auth/realms/ROCSAFE/account';
	},

	methods: {
		save() {
			console.log('POST', this.profile);
			this.saving = true;
			this.$http.post(this.uri, this.profile)
				.then(response => {
					console.log('POST RESP', response.data);
					this.saving = false;
					this.$emit('dismiss', this.profile);
				})
				.catch(error => {
					this.saving = false;
					this.errorHandler(error);
				});
		},
		errorHandler(error) {
			if (error.response) {
				// The request was made and the server responded with a status code
				// that falls out of the range of 2xx
				console.warn('ERROR: Data:', error.response.data);
				console.warn('ERROR: Status:', error.response.status);
				console.warn('ERROR: Headers:', error.response.headers);
			} else if (error.request) {
				// The request was made but no response was received
				console.warn('ERROR: Request', error.request);
			} else {
				// Something happened in setting up the request that triggered an Error
				console.warn('ERROR: Message', error.message);
			}
		}
	}
};
</script>
