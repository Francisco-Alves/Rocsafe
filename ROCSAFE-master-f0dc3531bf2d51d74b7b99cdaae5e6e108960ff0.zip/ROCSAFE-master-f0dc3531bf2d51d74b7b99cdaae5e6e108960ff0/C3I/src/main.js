/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import 'typeface-roboto/index.css';
import 'material-design-icons-iconfont/dist/material-design-icons.css';
import 'mdi/css/materialdesignicons.css';
import 'vuetify/src/stylus/app.styl';

import './filters/capitalize.js';
import './filters/camel2sentence.js';
import './filters/snake2sentence.js';

import Vue from 'vue';
import App from './App.vue';
import AxiosPlugin from './plugins/axios.js';
import TypeCheckPlugin from './plugins/type-check.js';
import UtilsPlugin from './plugins/utils.js';
import VImgFallback from 'v-img-fallback';
import * as VueGoogleMaps from 'vue2-google-maps';
import {
	Vuetify,
	VApp,
	VAvatar,
	VBtn,
	VBtnToggle,
	VCard,
	VCheckbox,
	VChip,
	VDatePicker,
	VDialog,
	VFooter,
	VForm,
	VGrid,
	VIcon,
	VList,
	VMenu,
	VNavigationDrawer,
	VProgressCircular,
	VSelect,
	VTextField,
	VToolbar,
	VTooltip
} from 'vuetify';

Vue.use(Vuetify, {
	components: {
		VApp,
		VAvatar,
		VBtn,
		VBtnToggle,
		VCard,
		VCheckbox,
		VChip,
		VDatePicker,
		VDialog,
		VFooter,
		VForm,
		VGrid,
		VIcon,
		VList,
		VMenu,
		VNavigationDrawer,
		VProgressCircular,
		VSelect,
		VTextField,
		VToolbar,
		VTooltip
	}
});

Vue.use(VImgFallback, {});

Vue.use(VueGoogleMaps, {
	load: {
		key: 'AIzaSyARys16e8MBLhRMVjUlXHQ-RkDM6ay_IcI',
		language: 'en',
		// libraries: 'places', // This is required if you use the Autocomplete plugin
		// OR: libraries: 'places,drawing'
		// OR: libraries: 'places,drawing,visualization'
		// (as you require)
	}
});

Vue.use(AxiosPlugin);
Vue.use(TypeCheckPlugin);
Vue.use(UtilsPlugin);

new Vue({
	el: '#app',
	render: h => h(App)
});
