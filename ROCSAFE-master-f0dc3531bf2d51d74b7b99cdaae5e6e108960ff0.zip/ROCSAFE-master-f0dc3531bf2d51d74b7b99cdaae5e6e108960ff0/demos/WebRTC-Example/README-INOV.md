$Id$

## WebRTC Usage Example

###  Adapted from https://github.com/shanet/WebRTC-Example

Changes made by INOV:
- Add example for client-server connection, i.e., were one browser just send its local media while the other justs receives:
  - client/server.html & client/webrtc-server.js: Streaming server (sender) 
  - client/client.html & client/webrtc-client.js: Streaming client (receiver)
- ESLint comply and JSBeautify formating

See [README.md](./README.md) to usage instructions.
