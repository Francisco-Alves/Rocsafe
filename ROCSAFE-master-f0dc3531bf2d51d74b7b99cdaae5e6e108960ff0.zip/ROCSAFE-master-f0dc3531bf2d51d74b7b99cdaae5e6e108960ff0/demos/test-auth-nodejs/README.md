# NODEJS API DEMO APP FOR KEYCLOAK

## Contents

This demo is a Nodejs demos to use keycloak for authentication/authorization.
In order for this to work, you need to add the host and port you are serving from
to the keycloak admin page to the "Valid Redirect URIs".

## Requirements

* Nodejs 
* node package manager (npm) 
* Keycloak Installed and configured
	