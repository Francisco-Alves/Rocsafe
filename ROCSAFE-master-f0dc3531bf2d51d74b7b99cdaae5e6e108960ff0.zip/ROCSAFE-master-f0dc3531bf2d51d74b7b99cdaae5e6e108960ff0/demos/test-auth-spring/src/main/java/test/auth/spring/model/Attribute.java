package test.auth.spring.model;

public class Attribute {
	public String name;
	public String value ;
}
