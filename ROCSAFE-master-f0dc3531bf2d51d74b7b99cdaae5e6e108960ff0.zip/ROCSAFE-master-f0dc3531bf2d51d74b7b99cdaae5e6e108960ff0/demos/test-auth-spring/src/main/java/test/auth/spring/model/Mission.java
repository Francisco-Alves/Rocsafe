/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
package test.auth.spring.model;

public class Mission {

	// --------------------------------------------------------------------------
	// Properties
	// --------------------------------------------------------------------------
	/**
	 * Mission ID 
	 */
	public int id; 
	/**
	 * mission name [for now its assigned as Greek Number
	 */
	public String name; 
	/**
	 * extra attribute.. 
	 */
	public String desc;

	// --------------------------------------------------------------------------
	// Constructors
	// --------------------------------------------------------------------------

	/**
	 * General Constructor
	 */
	public Mission() {
	}
	/**
	 * id constructor
	 * @param id
	 */
	public Mission(int id) {
		this.id = id;
	}
	/**
	 * id, desc Constructor
	 * 
	 * @param id
	 * @param desc
	 */
	public Mission(int id, String name) {
		this.id = id;
		this.name = name;
	}
	/**
	 * full constructor 
	 * @param id
	 * @param name
	 * @param desc
	 */
	public Mission(int id, String name, String desc) {
		this.id = id; 
		this.name= name; 
		this.desc= desc;
	}

	
	// --------------------------------------------------------------------------
	// set and get Methods
	// --------------------------------------------------------------------------
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
}
