package test.auth.spring.model;

public class Role {
	
	
}
