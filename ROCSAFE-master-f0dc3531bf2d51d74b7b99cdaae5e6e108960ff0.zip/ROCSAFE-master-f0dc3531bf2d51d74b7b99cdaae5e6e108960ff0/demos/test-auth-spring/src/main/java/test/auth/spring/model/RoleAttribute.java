package test.auth.spring.model;

public enum RoleAttribute { 
	mc_missions,  // for a role ==> MISSION_COMMANDER 
	csm_missions, // for a role ==> CRIME_CENCE_MANAGER
	sci_missions, // for a role ==> SENIOR_CRIME_INVISTIGATOR
	su_missions, // for a role ==> STANDARD_USER
	sa_missions, // for a role ==> SYSTEM_ADIMINSTRATOR 
}
