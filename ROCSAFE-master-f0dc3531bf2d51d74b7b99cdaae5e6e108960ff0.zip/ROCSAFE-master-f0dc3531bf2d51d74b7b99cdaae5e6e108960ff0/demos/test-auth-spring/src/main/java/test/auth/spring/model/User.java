/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
package test.auth.spring.model;

import java.util.Collection;

public class User {

	// --------------------------------------------------------------------------
	// Properties
	// --------------------------------------------------------------------------
	public String id;

	public String username;

	public String email;

	public String firstName;

	public String lastName;

	public Collection<String> roles;

	// --------------------------------------------------------------------------
	// Constructors
	// --------------------------------------------------------------------------
	public User() {
		
	}
	public User(String id , String username, String email) {
		this.id = id; 
		this.username = username;
		this.email = email; 
	}
	// --------------------------------------------------------------------------
	// Methods
	// --------------------------------------------------------------------------

}
