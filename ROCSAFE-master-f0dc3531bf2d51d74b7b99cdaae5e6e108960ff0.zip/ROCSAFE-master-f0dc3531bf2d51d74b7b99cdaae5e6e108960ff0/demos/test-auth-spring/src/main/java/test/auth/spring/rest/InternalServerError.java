/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
package test.auth.spring.rest;

 
public class InternalServerError extends RuntimeException {

	/**
	 * Handle the internal messages and Errors for API
	 */
	private static final long serialVersionUID = 1L;

	public InternalServerError() {
	}

	public InternalServerError(String message) {
		super(message);
	}

	public InternalServerError(String message, Throwable cause) {
		super(message, cause);
	}
}
