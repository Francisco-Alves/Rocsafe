package test.auth.spring.rest.admin;

import test.auth.spring.rest.API;

public class AdminAPI extends API{
	

}
