package test.auth.spring.rest.rocsafe;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import test.auth.spring.model.HumanResource;
import test.auth.spring.model.User;
import test.auth.spring.rest.API;
import test.auth.spring.services.UserService;

@RestController
@RequestMapping
public class UsersAPI extends API{
	 
	Logger log = LogManager.getLogger(UsersAPI.class);
	
	
	@Autowired
	UserService userSvc;
	
	/**
	 * List Summary of all agents
	 * @return
	 */
	@GetMapping("/v{version}/users/")
	public ArrayList<User> getUsers(){
		log.info("request List Users");
		return userSvc.getUsers();
	}
	
	/**
	 * Create a new Agent
	 * @param agentBody
	 * @return
	 */
	@PostMapping(path="/v{version}/users/")
	public User createUser(@RequestBody User userObject) {
		log.info("Request creating a new User");
		return userSvc.createUser(userObject);
	}
	
	/**
	 * List detailed infor for an agent.
	 * @param id
	 * @return
	 */
	@GetMapping("/v{version}/users/{id}")
	public User getUserObject(@PathVariable("id") String id ) {
		log.info("Request User Details info");
		return userSvc.getUser(id);
	}
	
	/**
	 * update agent info
	 * @param agentBody
	 * @return
	 */
	@PutMapping(path="/v{version}/users/{id}")
	public User updateUser(@RequestBody User userBody, @PathVariable("id") String id ) {
		log.info("Request Update User Info");
		return userSvc.updateUser(id, userBody);
	}
	
	/**
	 * detete a agent 
	 * @param id
	 * @return
	 */
	@DeleteMapping(path="/v{version}/users/{id}")
	public User deteteUser(@PathVariable("id") String id) {
		log.info("Request delete User info ");
		return userSvc.deleteUser(id);
	}
	
	
}
