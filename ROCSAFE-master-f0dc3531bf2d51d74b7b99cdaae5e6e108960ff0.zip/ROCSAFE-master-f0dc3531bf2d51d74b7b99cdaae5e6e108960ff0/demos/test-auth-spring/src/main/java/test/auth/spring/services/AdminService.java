package test.auth.spring.services;
 
import org.springframework.stereotype.Service;
 
@Service
public class AdminService {
	/**
	 * keycloak object
	 */
	String KEYCLOAK_SERVER_URL="http://localhost:8080/auth";
	String KEYCLOAK_REALM_NAME="master";
	String KEYCLOAK_CLIENT_ID="admin-cli"; 
	String KEYCLOAK_USERNAME="master"; 
	String KEYCLOAK_PASSWORD="master";
	/**
	 * Keycloak Object. 
	 */
	//Keycloak keycloak;
	
	public AdminService() {
		//this.keycloak= Keycloak.getInstance(KEYCLOAK_SERVER_URL, KEYCLOAK_REALM_NAME, KEYCLOAK_USERNAME, KEYCLOAK_PASSWORD, KEYCLOAK_CLIENT_ID); 
		
	}
	
	// EDIT KEYCLOAK USER INFO and ATTRIBUTES. 
	public void updateUserProfile() {
		
	}
}
