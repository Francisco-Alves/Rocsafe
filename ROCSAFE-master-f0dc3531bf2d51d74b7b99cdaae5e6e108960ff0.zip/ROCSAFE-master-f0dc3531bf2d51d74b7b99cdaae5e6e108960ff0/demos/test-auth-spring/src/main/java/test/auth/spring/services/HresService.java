package test.auth.spring.services;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import test.auth.spring.model.HumanResource;

@Service
public class HresService {
	
	Logger log = LogManager.getLogger(HresService.class);
	
	// ==========================================================
	// Instances 
	// ==========================================================
	ArrayList<HumanResource> Hres;
	
	
	// ==========================================================
	// Constructors 
	// ==========================================================
	
	public HresService() {
		setHresList();
	}


	private void setHresList() {
		this.Hres = new ArrayList<HumanResource>();
		Hres.add(new HumanResource("001", "MARY", "SMITH" , "MARY.SMITH@sakilacustomer.org", "F", "092923445" ));
		Hres.add(new HumanResource("002", "PATRICIA", "JOHNSON" , "PATRICIA.JOHNSON@sakilacustomer.org", "F", "092923445" ));
		Hres.add(new HumanResource("003", "LINDA", "WILLIAMS" , "LINDA.WILLIAMS@sakilacustomer.org", "F", "092923445" ));
		Hres.add(new HumanResource("004", "BARBARA", "JONES" , "BARBARA.JONES@sakilacustomer.org", "F", "092923445" ));
		Hres.add(new HumanResource("005", "ELIZABETH", "BROWN" , "ELIZABETH.BROWN@sakilacustomer.org", "F", "092923445" ));
		Hres.add(new HumanResource("006", "JENNIFER", "DAVIS" , "JENNIFER.DAVIS@sakilacustomer.org", "F", "092923445" ));
	}
	

	
	// ==========================================================
	// Methods  
	// ==========================================================
	public ArrayList<HumanResource> getHresList() {
		log.info("Request List of Human Resources objects ");
		return this.Hres;
	}
	
	public HumanResource getHresObject(String id) {

		log.info("Request Human Resources object ");
		for(HumanResource h : this.Hres) {
			if(h.id.equals(id)) {
				return h;
			}
		}
		return new HumanResource("N/A");
	}
	
	public HumanResource updateHres(String id, HumanResource hresObject) {

		log.info("Request to Update an Human Resource Object ");
		HumanResource h = getHresObject(id);
		if(h.id.equals("N/A")) {
			return h;
		}
		h.firstName = hresObject.firstName;
		h.lastName = hresObject.lastName;
		h.email = hresObject.email;
		h.gender = hresObject.gender; 
		h.phone = hresObject.phone;
		return h;
		
	}
	
	public HumanResource createHres(HumanResource hresObject) {
		log.info("Request to Create Human Resource Object");
		this.Hres.add(hresObject);
		return hresObject;
	}
	
	public HumanResource deleteHres(String id) {
		log.info("Request to delete Human Resource Object");
		HumanResource h = this.getHresObject(id);
		if(h.id.equals("N/A")) {
			return h;
		}
		this.Hres.remove(h);
		return h;
	}
}
