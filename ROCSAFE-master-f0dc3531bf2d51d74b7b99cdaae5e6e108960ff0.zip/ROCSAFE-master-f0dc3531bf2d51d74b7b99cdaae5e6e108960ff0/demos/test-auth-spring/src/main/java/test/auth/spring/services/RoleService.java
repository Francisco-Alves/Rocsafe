package test.auth.spring.services;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import test.auth.spring.model.RocsafeRole;

@Service
public class RoleService {

	Logger log = LogManager.getLogger(RoleService.class);

	public String[] NAMES = { "Mission Commander", "Crime Scene Manager", "Senior Crime Invistigator", "Standard User",
			"System Administrator" };

	public String[] ATTRIBUTES = { "mc_missions", "csm_missions", "sci_missions", "su_missions", "sa_missions" };

	public Map<RocsafeRole, String> ROLES;
	public Map<RocsafeRole, String> ROLES_ATTRIPUTES;

	public RoleService() {
		// fill ROLES-NAMES Map with values.
		this.ROLES = fillNames(this.ROLES);
		// file ROLES-ATTRIBUTES Map with values.
		this.ROLES_ATTRIPUTES = fillAttributes(this.ROLES_ATTRIPUTES);
	}

	// ==========================================================================
	// Utilities
	// ==========================================================================

	private String getRoleName(RocsafeRole role) {
		if (role == null) {
			throw new RuntimeException("RocsafeRole provided is null");
		}
		return this.NAMES[role.ordinal()];
	}

	private String getRoleNameById(int id) {
		if (id < 0) {
			log.info("Id provided for a role is ");
			throw new RuntimeException("RocsafeRole id is not suppoerted");
		}
		if (id > this.NAMES.length) {
			log.info("Id provided for a role is ");
			throw new RuntimeException("RocsafeRole id is not suppoerted");
		}
		return this.NAMES[id];
	}

	private String getRoleAttribute(RocsafeRole role) {
		if(role == null) {
			throw new RuntimeException("RocsafeRole id is not supported");
		}
		return this.ATTRIBUTES[role.ordinal()];
	}

	private Map<RocsafeRole, String> fillNames(Map<RocsafeRole, String> roles) {
		roles = new HashMap<RocsafeRole, String>();
		roles.put(RocsafeRole.MISSION_COMMANDER, getRoleName(RocsafeRole.MISSION_COMMANDER));
		roles.put(RocsafeRole.CRIME_SCENE_MANAGER, getRoleName(RocsafeRole.CRIME_SCENE_MANAGER));
		roles.put(RocsafeRole.SENIOR_CRIME_INFISTIGATOR, getRoleName(RocsafeRole.SENIOR_CRIME_INFISTIGATOR));
		roles.put(RocsafeRole.STADARD_USER, getRoleName(RocsafeRole.STADARD_USER));
		roles.put(RocsafeRole.SYSTEM_ADMINISTRATOR, getRoleName(RocsafeRole.SYSTEM_ADMINISTRATOR));
		return roles;
	}

	private Map<RocsafeRole, String> fillAttributes(Map<RocsafeRole, String> rolesAtt) {
		rolesAtt = new HashMap<RocsafeRole, String>();
		rolesAtt.put(RocsafeRole.MISSION_COMMANDER, getRoleAttribute(RocsafeRole.MISSION_COMMANDER));
		rolesAtt.put(RocsafeRole.CRIME_SCENE_MANAGER, getRoleAttribute(RocsafeRole.CRIME_SCENE_MANAGER));
		rolesAtt.put(RocsafeRole.SENIOR_CRIME_INFISTIGATOR, getRoleAttribute(RocsafeRole.SENIOR_CRIME_INFISTIGATOR));
		rolesAtt.put(RocsafeRole.STADARD_USER, getRoleAttribute(RocsafeRole.STADARD_USER));
		rolesAtt.put(RocsafeRole.SYSTEM_ADMINISTRATOR, getRoleAttribute(RocsafeRole.SYSTEM_ADMINISTRATOR));
		return rolesAtt;
	}

}
