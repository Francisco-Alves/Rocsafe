package test.auth.spring.services;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import test.auth.spring.model.User;

@Service
public class UserService {

	
	Logger log = LogManager.getLogger(UserService.class);
	
	
	ArrayList<User> users; 
	
	public UserService() {
		setUserList();
		
	}

	private void setUserList() {
		users = new ArrayList<User>();
		users.add(new User("001", "Omar", "omar@inov.com"));
		users.add(new User("002", "Jose", "jose@inov.com"));
		users.add(new User("003", "gabriel", "gabriel@inov.com"));
		users.add(new User("004", "martijn", "martijn@inov.com"));
		users.add(new User("005", "tiago", "tiago@inov.com")); 
	}
	
	public ArrayList<User> getUsers(){
		
		return this.users;
	}
	
	public User getUser(String id) { 
		for(User u: this.users) {
			if(u.id.equals(id)) {
				return u;
			}
		}
		
		return new User("N/A",null,null);
	}
	
	public User updateUser(String id, User userObject) {
		User u = getUser(id);
		if(u.id.equals("N/A")) {
			return u;
		}
		u.firstName= userObject.firstName;
		u.lastName = userObject.lastName;
		u.email = userObject.email;
		return u;
	}
	
	public User createUser(User userObject) {
		this.users.add(userObject);
		return userObject;
	}
	
	public User deleteUser(String id) {
		User u = getUser(id);
		if(u.id.equals("N/A")) {
			return u;
		}
		this.users.remove(u);
		return u;
	}

}
