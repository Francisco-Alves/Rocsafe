/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/


var HTTP_METHODS={
    POST:'POST',
        GET: 'GET',
        PUT:'PUT',
        DELETE:'DELETE',
        PATCH:'PATCH'
}
var DEFAULT_BODY='{}';
var BODY_ROVS='{ ' +
    '"id": "001" ,\n' +
    ' "desc": "Machine for collecting somthing",\n' +
    '"name": "Rov001",\n' +
    '"type": "RAV" \n' +
    '}';
var BODY_HRES='{\n' +
    '"id": "001" ,\n' +
    '"email": "F", \n' +
    '"firstName": "MARY",\n' +
    '"gender": "MARY.SMITH@sakilacustomer.org" , \n' +
    '"lastName": "SMITH" ,\n' +
    '"phone": "092923445" \n' +
    '}';
var BODY_MISSION='{ \n' +
    ' "id": "022", \n' +
    ' "name": "alfa"\n '+
    '}';
var BODY_USER='{ \n' +
    ' "id": "006", \n' +
    ' "username": "Jose", \n' +
    ' "email": "jose@inov.com" \n' +
    '}';

//=============================================================
// Start Vue.js Application
//=============================================================
var vm = new Vue({
	el: '#app',
	data: {
        KEYCLOAK_CONFIG_PATH:'frontend/config/keycloak.json',
        LOCAL_KEYCLOAK_CONFIG_PATH:'frontend/config/keycloak-local.json',
	    ACCESS_PERMISSIONS:{
            AUTHORIZED:'AUTHORIZED',
            UNAUTHORIZED:'UNAUTHORIZED',
            UNAUTHORIZED_TOKEN:'UNAUTHORIZED TOKEN',
            BAD_REQUEST:'BAD REQUEST',
            METHOD_NOT_ALLOWED:'METHOD NOT ALLOWED',
            INTERNAL_ERROR:'INTERNAL SERVER ERROR',
            UNKNOWN_ERROR:'UNKNOWN ERROR'
        },
        CLIENT_NAME_LOCAL:'usage-demo',
        API_BASE_URL: null,
        COPYRIGHTS:null,
        showContent:false,
	    showModal:false,
        showPage:false,
        testingResource:{
	        method:null,
            type:null,
            URI:null,
            description:null,
            param:null,
            paramValue:0,
            body:null,
            response:null,
            permission:null,
            responseBody:null
        },
	    user_page_info:'',
        keycloakObj:null,
		userName: null,
		userRole: null,
        requestCounter:0,
		selected:'mission',
        // dropbox options
		resources_options:[
            {text:'API Info', value:'api'},
			{text:'Missions', value:'mission' },
			{text:'Remotely Operated Vehicles', value:'rov'},
			{text:'Human Resources', value:'hres' },
            {text:'Business Rule Engine', value:'engine' },
            {text:'Users', value:'user'}
		],
        rocsafe_roles:[
            {name:'System Administrator', value:'system_administrator'},
            {name:'Resource Administrator', value:'resource_administrator'},
            {name:'Business Rule Administrator', value:'business_rule_administrator'},
            {name:'User', value:'user'}
        ],
		uri_resources:[
            // API VERSION
            {URI:'/api/v1/', method:HTTP_METHODS.GET, description:'Test Rule Engine end point',type:'api'},
            // Missions endpoint
			{URI:'/api/v1/missions/', method:HTTP_METHODS.POST, description:'Creates a new mission', type:'mission'},
            {URI:'/api/v1/missions/', method:HTTP_METHODS.GET, description:'Lists summaries of missions',type:'mission'},
            {URI:'/api/v1/missions/{mission_id}', method:HTTP_METHODS.GET, description:'List details for a mission',type:'mission'},
            {URI:'/api/v1/missions/{mission_id}', method:HTTP_METHODS.PUT, description:'Update details for a mission',type:'mission'},
            {URI:'/api/v1/missions/{mission_id}', method:HTTP_METHODS.DELETE, description:'Deletes a mission',type:'mission'},
            // Remotly Operated Vehicle endpoint
            {URI:'/api/v1/rovs/', method:HTTP_METHODS.POST, description:'Creates a new ROV',type:'rov'},
            {URI:'/api/v1/rovs/', method:HTTP_METHODS.GET, description:'Lists summary info for all ROVs',type:'rov'},
            {URI:'/api/v1/rovs/{rov_id}', method:HTTP_METHODS.GET, description:'List detailed info for ROV',type:'rov'},
            {URI:'/api/v1/rovs/{rov_id}', method:HTTP_METHODS.DELETE, description:'Delete the ROV',type:'rov'},
            {URI:'/api/v1/rovs/{rov_id}', method:HTTP_METHODS.PUT, description:'Updates the ROV',type:'rov'},
            // Human Resources endpoint
            {URI:'/api/v1/hres/', method:HTTP_METHODS.POST, description:'Create a new human resource',type:'hres'},
            {URI:'/api/v1/hres/', method:HTTP_METHODS.GET, description:'List Summary of all a human resource',type:'hres'},
            {URI:'/api/v1/hres/{hre_id}', method:HTTP_METHODS.GET, description:'List detailed info for a human resource',type:'hres'},
            {URI:'/api/v1/hres/{hres_id}', method:HTTP_METHODS.PUT, description:'Update detailed info for a human resource',type:'hres'},
            {URI:'/api/v1/hres/{hres_id}', method:HTTP_METHODS.DELETE, description:'Delete a human resource',type:'hres'},
            // users end point
            {URI:'/api/v1/users/', method:HTTP_METHODS.POST, description:'Create a new User',type:'user'},
            {URI:'/api/v1/users/', method:HTTP_METHODS.GET, description:'List Summary of all a User ',type:'user'},
            {URI:'/api/v1/users/{id}', method:HTTP_METHODS.GET, description:'List detailed info for a User',type:'user'},
            {URI:'/api/v1/users/{id}', method:HTTP_METHODS.PUT, description:'Update detailed info for a User',type:'user'},
            {URI:'/api/v1/users/{id}', method:HTTP_METHODS.DELETE, description:'Delete a user',type:'user'},
            // users end point
            {URI:'/rule-engine/', method:HTTP_METHODS.GET, description:'Test Rule Engine end point',type:'engine'}

            ]

	},
    created:function(){
	    this.COPYRIGHTS="© " + new Date().getFullYear() + " ROCSAFE Consortium | INOV ";
        this.API_BASE_URL = location.origin + location.pathname;
        if (this.API_BASE_URL[this.API_BASE_URL.length - 1] === '/') {
            this.API_BASE_URL = this.API_BASE_URL.substring(0, this.API_BASE_URL.length - 1);
        }
        //console.log('API_BASE_URL', this.API_BASE_URL);
        if(typeof Keycloak ==="undefined"){
            alert('Failed to connect to Keycloak server');
            return ;
        }
        // load the host Keycloak library
        if(location.host === 'localhost:8088'){
            this.keycloakObj= Keycloak(this.LOCAL_KEYCLOAK_CONFIG_PATH);

        }else{
            this.keycloakObj= Keycloak(this.KEYCLOAK_CONFIG_PATH);
        }
        self= this;
        this.keycloakObj.init({ onLoad: 'login-required' }).success(function () {
                // get main user info
                self.setUserMainInfo(self.keycloakObj.tokenParsed);
                self.showMainInfo();
                console.log(self.keycloakObj);
            }).error(function () {
                alert('Keycloak is not available ! ');
            });
    },
    // methods in VueJS
    methods:{
        //=============================================================
        // Event Handlers
        //=============================================================
        showUserInfo: function(){
            user_info_page = this.API_BASE_URL + '/user_info.html';
            //console.log(user_info_page)
            //history.pushState({},'Main Page', "index.html")
            this.requestPageInfo(user_info_page)
        },
        user_logout:function () {
            obj = {'redirectUri': location.origin + '/test-auth-spring/' };
            this.keycloakObj.logout(obj);
        },
        showTestingPlatform:function(item){
            this.showModal=true;
            //console.log(item)
            this.setTestingResourceAttributes(item);
        },
        apiPerformRequest:function(resource){
            switch (resource.method){
                case HTTP_METHODS.GET:
                    this.api_get(resource);
                    break;
                case HTTP_METHODS.POST:
                    this.api_post(resource);
                    break;
                case HTTP_METHODS.PUT:
                    this.api_put(resource);
                    break;
                case HTTP_METHODS.DELETE:
                    this.api_delete(resource);
                    break;
                default:
                    console.log('Method is not specified ! ')
            }
        },

        //=============================================================
        // HTTP API.
        //=============================================================
        api_get: function (resource) {
            console.log('GET request !')
            var config = this.getToken();
            self = this;
            fullURL = this.buildFullURL(resource);
            if(!this.keycloakObj.isTokenExpired()) {
                axios.get(fullURL, config)
                    .then(function (response) {
                        //console.log(response);
                        switch (response.status) {
                            case 200:
                                self.setAuthorizedResponse(response);
                                break;
                            default:
                                self.setUnauthorizedResponse(response);
                        }
                    })
                    .catch(function (error) {
                        console.log('Error is :: ' + error);
                        self.setUnauthorizedResponse(error.response);
                    });
            }
        },
        api_post: function (resource) {
            console.log('POST request ! ')
            fullURL = this.buildFullURL(resource);
            console.log(this.testingResource.body);
            requestBody = this.parseBody(this.testingResource.body);
            var config = this.getToken();
            self = this;
            if (requestBody != null) {
                if(!this.keycloakObj.isTokenExpired()) {
                    axios.post(fullURL, JSON.parse(this.testingResource.body), config)
                        .then(function (response) {
                            //console.log(response);
                            switch (response.status) {
                                case 200:
                                    self.setAuthorizedResponse(response);
                                    break;
                                default:
                                    self.setUnauthorizedResponse(response);
                            }
                        })
                        .catch(function (error) {
                            console.log('Error is :: ' + error);
                            self.setUnauthorizedResponse(error.response);
                        });
                }
            }
        },
        api_put: function (resource) {
            console.log('PUT request ! ')
            self = this;
            fullURL = this.buildFullURL(resource);
            //console.log(vm.testingResource.body);
            var config = this.getToken();
            requestBody = this.parseBody(this.testingResource.body);
            if (requestBody != null) {
                if(!this.keycloakObj.isTokenExpired()) {
                    axios.put(fullURL, JSON.parse(this.testingResource.body), config)
                        .then(function (response) {
                            //console.log(response);
                            switch (response.status) {
                                case 200:
                                    self.setAuthorizedResponse(response);
                                    break;
                                default:
                                    self.setUnauthorizedResponse(response);
                            }
                        })
                        .catch(function (error) {
                            console.log('Error :' + error);
                            self.setUnauthorizedResponse(error.response);
                        });
                }
            }
        },
        api_delete: function (resource) {
            console.log('DELETE request ! ')
            fullURL = this.buildFullURL(resource);
            //console.log(vm.testingResource.body);
            var config = this.getToken();
            requestBody = this.parseBody(this.testingResource.body);
            self = this;
            if (requestBody != null) {
                if(!this.keycloakObj.isTokenExpired()){
                    axios.delete(fullURL, config)
                        .then(function (response) {
                            //console.log(response);
                            switch (response.status) {
                                case 200:
                                    self.setAuthorizedResponse(response);
                                    break;
                                default:
                                    self.setUnauthorizedResponse(response);
                            }
                        })
                        .catch(function (error) {
                            console.log(error.response)
                            self.setUnauthorizedResponse(error.response);
                        });
                }else{

                }


            }
        },

        //=============================================================
        // Utilities
        //=============================================================
        setUserMainInfo: function (tokenParsed) {
            this.userName = tokenParsed.preferred_username;
            this.userRole = this.getUserRole(tokenParsed);
        },
        getUserRole:function(tokenParsed){
            var userRoles =[];
            var userRole = null;
            var k=0;
            try {
                for (j = 0; j < tokenParsed.realm_access.roles.length; j++) {
                    var roleValue = tokenParsed.realm_access.roles[j];
                    for (i = 0; i < this.rocsafe_roles.length; i++) {
                        var roleObj = this.rocsafe_roles[i];

                        if (roleObj.value === roleValue) {
                            //console.log(roleObj.name);
                            userRoles[k] = roleObj.name;
                            k++;
                        }
                    }
                }
                console.log(userRoles.toString());
                userRole= userRoles[0];
                if(!userRole){
                    throw "Role is not a found!";
                }
            }catch(error){
                    // Some error are found when building the role.
                    userRole = "\<Role Not Found\>";
                    //alert('User should have assigned to a client role');
                    console.log(error);
            }
            return userRole;
        },
        getToken: function () {
            self = this;
            var token = null;
            if (this.keycloakObj.isTokenExpired()) {
                this.keycloakObj.updateToken(5).success(function (refreshed) {
                    if (refreshed) {
                        console.log('refereshed object is : ' + refreshed);
                        token = {
                            headers: {'Authorization': 'bearer ' + self.keycloakObj.token}
                        };
                    }
                    self.apiPerformRequest(self.testingResource);

                }).error(function () {
                    alert('Failed to refresh the token, or the session has expired');
                });
            } else {
                console.log('Token is still valid ! ');
                token = {
                    headers: {'Authorization': 'bearer ' + this.keycloakObj.token}
                };
            }

            return token;
        },
        getResourceOptionText:function(type){
            for(i=0; i < this.resources_options.length; i++){
                if(type===this.resources_options[i].value){
                    console.log(this.resources_options[i].text)
                    return (this.resources_options[i].text);
                }
            }
        },
        setTestingResourceAttributes:function(item){
            this.testingResource.type= this.getResourceOptionText(item.type);
            this.testingResource.URI=item.URI;
            this.testingResource.method= item.method;
            this.testingResource.paramValue=0;
            this.testingResource.description=item.description;
            this.testingResource.param=this.getParamsFromURI(item.URI);
            this.testingResource.permission='';
            this.testingResource.body=this.getDefaultBody();
        },
        getDefaultBody:function(){
                if( this.testingResource.type==='Missions') {
                    return BODY_MISSION;
                }else
                if(this.testingResource.type==='Remotely Operated Vehicles') {
                    return BODY_ROVS;
                }else
                if(this.testingResource.type==='Human Resources'){
                    return BODY_HRES;
                }else
                if(this.testingResource.type==='Users') {
                    return BODY_USER;
                }
                return DEFAULT_BODY;

        },
        getParamsFromURI:function(URI){
            var param =null;
            if(URI.indexOf('{') != -1){
                param = URI.substring(URI.indexOf('{'), URI.indexOf('}')+1);

            }
            return param;
        },
        hasParam:function(param){
            if(param == null){
                return false;
            }else{
                return true;
            }
        },
        hasBody:function(method){
            if(method === HTTP_METHODS.PUT || method ===HTTP_METHODS.POST){
                return true;
            }else{
                return false;
            }
        },
        hasPermission:function (permission) {
            if(permission===this.ACCESS_PERMISSIONS.AUTHORIZED){
                return true;
            }else{
                return false;
            }
        },
        buildFullURL:function (resource) {
            var fullURI;
            if(this.hasParam(resource.param)){
                UrlWithoutId = resource.URI.substring(0,resource.URI.indexOf('{'));
                fullURI = this.API_BASE_URL + UrlWithoutId + this.testingResource.paramValue ;
           }else{
                fullURI = this.API_BASE_URL + resource.URI;
            }
            console.log(fullURI);
            return fullURI;
        },
        parseBody:function(text){
            dataBody=null;
            try{
                dataBody = JSON.parse(text);
            }catch (e){
                this.testingResource.permission='JSON ERROR !' ;
            }
            return dataBody;
        },
        requestPageInfo: function (info_uri) {
            window.location.assign(info_uri)
        },
        setAuthorizedResponse:function(response){
            console.log(response)
            this.testingResource.permission=this.ACCESS_PERMISSIONS.AUTHORIZED;
            console.log(response.data);
            this.testingResource.responseBody= JSON.stringify(response.data, undefined, 4);
        },
        setUnauthorizedResponse: function (response) {
            console.log('Response Status ' + response.status)
            console.log(this.testingResource.paramValue);
            if (typeof response.status !== 'undefined') {
                switch (response.status) {
                    case 500:
                        console.log("Counter is " + this.requestCounter);
                        if (this.requestCounter == 0) {
                            this.requestCounter = 1;
                            this.apiPerformRequest(this.testingResource);
                            console.log("Second time request is : " + this.testingResource);
                        } else {
                            console.log('counter is :' + this.requestCounter);
                            this.testingResource.permission = this.ACCESS_PERMISSIONS.INTERNAL_ERROR;
                        }
                        break;
                    case 405:
                        this.testingResource.permission = this.ACCESS_PERMISSIONS.METHOD_NOT_ALLOWED;
                        break;
                    case 403:
                        this.testingResource.permission = this.ACCESS_PERMISSIONS.UNAUTHORIZED;
                        break;
                    case 400:
                        this.testingResource.permission = this.ACCESS_PERMISSIONS.BAD_REQUEST;
                        break;
                    case 401:
                        this.testingResource.permission = this.ACCESS_PERMISSIONS.UNAUTHORIZED_TOKEN;
                        break;
                    default:
                        this.testingResource.permission = this.ACCESS_PERMISSIONS.UNKNOWN_ERROR + response;
                }
            }
        },
        showMainInfo:function() {
            this.showContent = true;
            this.showPage=true;
        }
    },
    components:{
	    'modal':{
            template: '#modal-template'
        }
    }
});





