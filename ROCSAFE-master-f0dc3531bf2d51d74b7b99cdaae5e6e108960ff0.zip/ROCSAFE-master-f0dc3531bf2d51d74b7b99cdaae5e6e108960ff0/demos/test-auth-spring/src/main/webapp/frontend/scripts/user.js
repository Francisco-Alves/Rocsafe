/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

var CLIENT_NAME_LOCAL='usage-demo';

var user_info_vm = new Vue({
    el:'#info_app',
    data: {
        KEYCLOAK_CONFIG_PATH:'frontend/config/keycloak.json',
        LOCAL_KEYCLOAK_CONFIG_PATH:'frontend/config/keycloak-local.json',
        LOCALHOST:'localhost:8088',
        APP_BASE_URL:null,
        showContent:false,
        keycloakObj:null,
        ShowRoleMatrix:false,
        rocsafe_roles:[
            {name:'Crime Scene Manager', value:'crime_scene_manager'},
            {name:'Mission Commander', value:'mission_commander'},
            {name:'Senior Crime Investigator', value:'senior_crime_investigator'},
            {name:'System Administrator', value:'system_administrator'},
            {name:'Standard User', value:'standard_user'}
        ],
        missionsKeys:[
            {name:'Crime Scene Manager', key:'csm_missions'},
            {name:'Mission Commander', key:'mc_missions'},
            {name:'Senior Crime Investigator', key:'sci_missions'},
            {name:'Standard User', key:'su_missions'}

        ],
        searchQuery: '',
        gridColumns: ['role','missions'],
        missionsRolesTable:[],
        greekNumbers:[
            {name:'alfa', id:'1'},
            {name:'beta', id:'2'},
            {name:'gamma', id:'3'},
            {name:'delta', id:'4'},
            {name:'epsilon', id:'5'},
            {name:'vou', id:'6'},
            {name:'zeta', id:'7'},
            {name:'eta', id:'8'},
            {name:'theta', id:'9'},
            {name:'iota', id:'10'},
            {name:'keppa', id:'20'},
            {name:'lambda', id:'30'},
            {name:'mu', id:'40'},
            {name:'nu', id:'50'},
            {name:'xi', id:'60'},
            {name:'omicron', id:'70'},
            {name:'pi', id:'80'},
            {name:'koppa', id:'90'},
            {name:'rho', id:'100'}
        ],
        fullName:'N/A',
        familyName:'N/A',
        mobile:'N/A',
        name:'N/A',
        address:'N/A',
        username: 'N/A',
        email: 'N/A',
        userRole: 'N/A',
        photo_url:'N/A',
        post_box:'N/A'
    },

    //=============================================================
    // Hooks Lifecycle
    //=============================================================
    created: function () {
        this.APP_BASE_URL = location.origin + location.pathname;
        if (this.APP_BASE_URL[this.APP_BASE_URL.length - 1] === '/') {
            this.APP_BASE_URL = this.APP_BASE_URL.substring(0, this.APP_BASE_URL.length - 1);
        }
        // change keycloak config based on the deployed location


        // when the keycloak server is down
        if (typeof Keycloak === "undefined") {
            alert('Failed to connect to Keycloak server');
            return;
        }
        // if the host is local , put another
        if(location.host === this.LOCALHOST ){
            this.keycloakObj = Keycloak(this.LOCAL_KEYCLOAK_CONFIG_PATH);
        }else{
            this.keycloakObj = Keycloak(this.KEYCLOAK_CONFIG_PATH);
        }
        self = this;
        this.keycloakObj.init().success(function (authenticated) {
            if (authenticated) {
                console.log(self.keycloakObj);
                self.requestUserInfo(self.keycloakObj);
                self.showInfo();
            } else {
                self.keycloakObj.login();
            }
        });

    },

    methods:{
        //=============================================================
        // Event Handlers
        //=============================================================
        show_main:function(){
            var main_page = window.location.href.substr(0,window.location.href.indexOf('user_info.html'));
            window.location.hash='main';
            console.log(window.location.hash)
            window.location.assign(main_page)
        },

        onClickBackButton:function(){

        },
        getHomeURL:function(){
            if(location.origin==='localhost:8088'){
                return
            }else{

            }
        },
        //=============================================================
        // Utilities
        //=============================================================
        requestUserInfo:function(keycloak) {
            self= this;
            keycloak.loadUserProfile().success(function(profile) {
                console.log(profile);
                // Set User Profile
                self.setUserMainInfo(profile)
                self.setUserAttributes(profile)
                user_info_vm.userRole= self.getUserRole(keycloak.tokenParsed);

            }).error(function() {
                alert('Failed to load user profile');
            });

        },
        showInfo:function () {
            user_info_vm.showContent = true;
        },
        getUserRole:function(tokenParsed){
            var userRole = null;
            var userRoles= [];
            var k=0;
            try {
                for (j = 0; j < tokenParsed.realm_access.roles.length; j++) {
                    var roleValue = tokenParsed.realm_access.roles[j];
                    for (i = 0; i < this.rocsafe_roles.length; i++) {
                        var roleObj = this.rocsafe_roles[i];
                        if (roleObj.value === roleValue) {
                            console.log(roleObj.name);
                            userRoles[k] = roleObj.name;
                            k++;
                        }
                    }
                }
                console.log(userRoles.toString());
                userRole= userRoles[0];
                if(!userRole){
                    throw "Role is not a found!";
                }
            }catch(error){
                // Some error are found when building the role.
                userRole = "\<Role Not Found\>";
                //alert('User should have assigned to a client role');
                console.log(error)
            }
            return userRole;
        },
        setUserAttributes:function(profile){
            try{
                user_info_vm.mobile=this.getAttributeIfExist(profile.attributes.mobile);
                user_info_vm.address= this.getAttributeIfExist(profile.attributes.address);
                user_info_vm.postalCode= this.getAttributeIfExist(profile.attributes.postalCode);
                user_info_vm.setUserMissionsTable(profile)
            }catch(error){
                // error should be showing
                //alert('Error in retrieving User Attributes');
                console.log(error);
            }
        },
        getAttributeIfExist:function(attr){
            if(typeof(attr) !=="undefined"){
                return attr[0];
            }
            return 'N/A';
        },
        getIfExist:function(obj){
            if(typeof(obj) !=="undefined"){
                return obj;
            }
            return 'N/A';
        },
        setUserMainInfo:function(profile){
            try{
                user_info_vm.username =this.getIfExist( profile.username);
                user_info_vm.email = this.getIfExist(profile.email);
                user_info_vm.name=this.getIfExist(profile.firstName);
                user_info_vm.fullName= this.getIfExist(profile.firstName + ' ' + profile.lastName);
                user_info_vm.familyName= this.getIfExist(profile.lastName);

            }catch(error){
                // show an alert;
                //alert('Error happened retrieving User Attributes ');
                console.log("Error happened on retrieving User Attributes" + error);
            }

        },
        setUserMissionsTable:function(profile){
            self = this;
                for(i=0; i < this.missionsKeys.length; i++){
                    console.log(this.missionsKeys[i].key)
                    var mKey = this.missionsKeys[i].key;
                    var mName = this.missionsKeys[i].name;
                    if(profile.attributes.hasOwnProperty(mKey)){
                        var mValue = profile.attributes[mKey];
                        console.log('attribute name:'+ mKey + '  with value: '+ mValue)
                        this.addMissionsRolesRow(mName,mKey,mValue);
                    }
                }
            if(this.missionsRolesTable.length>0){
                console.log('user has no roles');
                this.ShowRoleMatrix=true;
            }
        },
        addMissionsRolesRow:function(mName,mKey,mValue) {
            var count = this.missionsRolesTable.length;
            var missionsArray= []
            var mIds = mValue.toString().split(',');
            for(j=0; j<mIds.length; j++){
                var greeckName = this.getGreekName(mIds[j]);
                missionsArray[j] = {id:mIds[j], name:greeckName}
            }
            this.missionsRolesTable[count] = {role: mName, missions:missionsArray };

            //console.log('The new object is added '+ this.missionsRolesTable[count]);
        },

        getMissionName:function(key){
            for(mission in this.greekNumbers){
                if(mission.key===key){
                    return mission.name;
                }
            }
            return null;
        },
        getGreekName:function(number){
            for(k=0; k<this.greekNumbers.length;k++){
                if(number===this.greekNumbers[k].id){
                    console.log('number for mission is '+ this.greekNumbers[k].id);
                    return this.greekNumbers[k].name;
                }
            }
        },
        getMissionUrl:function (Id) {
            var base = location.origin + '/test-auth-spring';
            return base +'/api/v1/missions/' + Id +'/';
        }
    }

})