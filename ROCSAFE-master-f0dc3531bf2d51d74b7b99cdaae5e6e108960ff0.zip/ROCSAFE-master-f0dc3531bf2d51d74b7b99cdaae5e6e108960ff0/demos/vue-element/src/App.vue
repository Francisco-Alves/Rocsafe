<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<div id="app">
		<a href="https://vuejs.org" target="_blank">
			<el-tooltip class="item" content="Vue.js - The Progressive JavaScript Framework" placement="left">
				<img :height="logoH" src="./assets/vue-logo.png" alt="Vue logo">
			</el-tooltip>
		</a>
		<a href="http://element.eleme.io" target="_blank">
			<el-tooltip class="item" effect="light" content="Element - A Vue.js 2.0 UI Toolkit" placement="right">
				<img :height="logoH" src="./assets/element-logo.png">
			</el-tooltip>
		</a>
		<h2>{{ msg }}</h2>
		<el-button type="success" @click="alert('Success')">Success</el-button>
		<el-select v-model="player" placeholder="Select a player...">
			<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item">
			</el-option>
		</el-select>
		<el-button type="danger" @click="alert('Danger')">Danger</el-button>
		<p v-if="player">You have selected player <b>{{ player.label }}</b> that carries jersey number <b>{{ player.value }}</b></p>
	</div>
</template>

<script>
export default {
	name: 'App',
	data() {
		return {
			msg: 'Vue.js & Element Demo App',
			options: [
				{
					value: 28,
					label: 'Bas Dost'
				},
				{
					value: 77,
					label: 'Gelson Martins'
				},
				{
					value: 8,
					label: 'Bruno Fernandes'
				},
				{
					value: 4,
					label: 'Sebastián Coates'
				},
				{
					value: 1,
					label: 'Rui Patrício'
				}
			],
			player: null,
			logoH: 80
		};
	},
	methods: {
		alert(msgType) {
			this.$alert('You have pressed the<br><strong>' + msgType + '</strong> button.', msgType, {
				dangerouslyUseHTMLString: true,
				confirmButtonText: 'OK',
				type: (msgType === 'Success') ? 'success' : 'error',
				center: true
			});
		}
	}
};
</script>

<style>
#app {
	font-family: 'Avenir', Helvetica, Arial, sans-serif;
	text-align: center;
	margin-top: 20px;
}
h1,
h2 {
	font-weight: normal;
}
img,
.el-select {
	margin: 0 10px;
}
</style>
