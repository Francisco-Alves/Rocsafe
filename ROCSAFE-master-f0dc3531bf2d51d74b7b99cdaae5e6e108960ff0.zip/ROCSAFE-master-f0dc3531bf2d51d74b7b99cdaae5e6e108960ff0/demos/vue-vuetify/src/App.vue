<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-app>
		<div class="text-xs-center">
			<a href="https://vuejs.org" target="_blank">
				<v-tooltip left color="green">
					<img slot="activator" :height="logoH" src="./assets/vue-logo.png">
					<span>Vue.js - The Progressive JavaScript Framework</span>
				</v-tooltip>
			</a>
			<a href="https://vuetifyjs.com/" target="_blank">
				<v-tooltip right color="blue">
					<img slot="activator" :height="logoH" src="./assets/vuetify-logo.png">
					<span>Vuetify - Material Component Framework for Vue.js 2</span>
				</v-tooltip>
			</a>
			<h2>{{ msg }}</h2>
			<v-container>
				<v-layout row justify-center wrap>
					<v-flex xs12 sm3>
						<v-btn color="success" @click="alert('Success')" @click.native.stop="dialog = true">Success</v-btn>
					</v-flex>
					<v-flex xs12 sm4>
						<v-select v-model="player" :items="options" label="Select a player"></v-select>
					</v-flex>
					<v-flex xs12 sm3>
						<v-btn color="error" @click="alert('Danger')" @click.native.stop="dialog = true">Danger</v-btn>
					</v-flex>
				</v-layout>
			</v-container>
			<p v-if="player">You have selected player <b>{{ player.name }}</b> that carries jersey number <b>{{ player.number }}</b></p>
		</div>
		<v-dialog v-model="dialog" persistent max-width="300">
			<v-card>
				<v-alert :color="modalBgVariant" :icon="modalIcon" value="true">
					{{ modalMsgType }}
				</v-alert>
				<v-card-text>You have pressed the <strong>{{ modalMsgType }}</strong> button!
				</v-card-text>
				<v-card-actions>
					<v-spacer></v-spacer>
					<v-btn color="info darken-1" flat="flat" @click.native="dialog = false">Dismiss</v-btn>
				</v-card-actions>
			</v-card>
		</v-dialog>
	</v-app>
</template>

<script>
export default {
	name: 'App',
	data() {
		return {
			msg: 'Vue.js & Vuetify Demo App',
			options: [
				{
					value: {
						number: 28,
						name: 'Bas Dost'
					},
					text: 'Bas Dost'
				},
				{
					value: {
						number: 77,
						name: 'Gelson Martins'
					},
					text: 'Gelson Martins'
				},
				{
					value: {
						number: 8,
						name: 'Bruno Fernandes'
					},
					text: 'Bruno Fernandes'
				},
				{
					value: {
						number: 4,
						name: 'Sebastián Coates'
					},
					text: 'Sebastián Coates'
				},
				{
					value: {
						number: 1,
						name: 'Rui Patrício'
					},
					text: 'Rui Patrício'
				}
			],
			player: null,
			logoH: 80,
			modalMsgType: null,
			modalBgVariant: null,
			modalIcon: null,
			dialog: false
		};
	},
	methods: {
		alert(msgType) {
			this.modalMsgType = msgType;
			switch (msgType) {
			case 'Danger':
				this.modalBgVariant = 'error';
				this.modalIcon = 'warning';
				break;
			case 'Success':
				this.modalBgVariant = 'success';
				this.modalIcon = 'check_circle';
				break;
			}
			console.log('You have pressed the ' + msgType + ' button.');
		}
	}
};
</script>

<style>
html {
	overflow-y: hidden;
}
img {
	margin: 10px;
}
</style>
