/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import 'typeface-roboto/index.css';
import 'material-design-icons-iconfont/dist/material-design-icons.css';
import 'vuetify/src/stylus/app.styl';

import Vue from 'vue';
import App from './App.vue';
import {
	Vuetify,
	VApp,
	VAlert,
	VBtn,
	VCard,
	VDialog,
	VGrid,
	VSelect,
	VTooltip,
} from 'vuetify';

Vue.use(Vuetify, {
	components: {
		VApp,
		VAlert,
		VBtn,
		VCard,
		VDialog,
		VGrid,
		VSelect,
		VTooltip,
	}
});

new Vue({
	el: '#app',
	render: h => h(App)
});
