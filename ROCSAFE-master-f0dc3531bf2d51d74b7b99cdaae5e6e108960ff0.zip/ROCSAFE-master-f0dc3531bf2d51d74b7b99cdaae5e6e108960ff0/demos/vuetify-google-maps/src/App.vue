<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-app>
		<v-container fluid class="pa-0">
			<v-content class="fill-height">
				<gmap-map ref="gmap" :center="map.center" :zoom="map.zoom" :options="map.options" class="fill-height" @center_changed="mapCenterChanged" @zoom_changed="mapZoomChanged" @idle="mapIdle">
				</gmap-map>
			</v-content>
		</v-container>
	</v-app>
</template>

<script>
import mapStyle from './config/map-style.json';
import {
	loaded as mapsLoaded
} from 'vue2-google-maps';

export default {
	name: 'App',

	data() {
		return {
			map: {
				center: {
					lat: 38.735086,
					lng: -9.141247
				},
				zoom: 10,
				options: {
					minZoom: 2,
					maxZoom: null,
					streetViewControl: false,
					styles: mapStyle
				}
			}
		};
	},

	mounted() {
		mapsLoaded.then(() => {
			var map = this.map;
			map.maxZoomService = new google.maps.MaxZoomService();
			map.reportedCenter = new google.maps.LatLng(map.center.lat, map.center.lng);
			map.reportedZoom = map.zoom;
			map.centerChanged = true;
		});
	},

	methods: {
		mapCenterChanged(center) {
			this.map.reportedCenter = center;
			this.map.centerChanged = true;
		},
		mapZoomChanged(zoom) {
			this.map.reportedZoom = zoom;
			this.updateZoomButtons();
		},
		mapIdle() {
			var map = this.map;
			if (!map.centerChanged) return;
			map.centerChanged = false;
			map.maxZoomService.getMaxZoomAtLatLng(map.reportedCenter, response => {
				map.options.maxZoom = (response.status === 'OK' ? response.zoom : null);
				console.log('Map: Max Zoom:', map.options.maxZoom);
				// TODO: Replace setTimeout by updateZoomButtons call on event (which?)
				setTimeout(() => {
					this.updateZoomButtons();
				}, 50);
			});
		},
		updateZoomButtons() {
			var zoomOutElem = this.$refs.gmap.$el.querySelector('button[title="Zoom out"]');
			if (zoomOutElem === null) return;
			var zoomInElem = this.$refs.gmap.$el.querySelector('button[title="Zoom in"]');
			if (zoomInElem === null) return;
			var map = this.map;
			var options = map.options;
			if (map.reportedZoom <= options.minZoom) {
				console.log('Map: Reached Min Zoom:', map.reportedZoom);
				zoomOutElem.setAttribute('disabled', '');
			} else if (options.maxZoom !== null && map.reportedZoom >= options.maxZoom) {
				console.log('Map: Reached Max Zoom:', map.reportedZoom);
				zoomInElem.setAttribute('disabled', '');
			} else {
				zoomOutElem.removeAttribute('disabled');
				zoomInElem.removeAttribute('disabled');
			}
		}
	}
};
</script>

<style>
html {
	overflow-y: hidden;
}
.gm-style button:disabled {
	opacity: 0.5 !important;
	cursor: not-allowed !important;
}
</style>
