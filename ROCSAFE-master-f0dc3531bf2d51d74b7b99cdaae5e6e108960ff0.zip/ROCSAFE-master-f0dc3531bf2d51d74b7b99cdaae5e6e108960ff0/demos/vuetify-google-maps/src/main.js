/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import 'typeface-roboto/index.css';
import 'material-design-icons-iconfont/dist/material-design-icons.css';
import 'vuetify/src/stylus/app.styl';

import Vue from 'vue';
import App from './App.vue';
import * as VueGoogleMaps from 'vue2-google-maps';
import {
	Vuetify,
	VApp,
	VGrid
} from 'vuetify';

Vue.use(Vuetify, {
	components: {
		VApp,
		VGrid
	}
});

Vue.use(VueGoogleMaps, {
	load: {
		key: 'AIzaSyARys16e8MBLhRMVjUlXHQ-RkDM6ay_IcI',
		language: 'en'
	}
});

new Vue({
	el: '#app',
	render: h => h(App)
});
