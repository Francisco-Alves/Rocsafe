# C3I

> ROCSAFE's Command & Control Center

## Build Setup

``` bash
# Install dependencies
npm install

# Serve with hot reload at localhost. It will run on port 8080 by default.
# If that port is already in use, the next free port will be used.
npm run dev

# Build for production with minification
npm run build

# Deploy bundled package to production server
npm run deploy

# Lint source code
npm run lint

# Clean both development and build folders
npm run clean
```

For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).


## Run from localhost
In order to run the server from localhost, the code needs to be altered in 2 places:
- In src/App.vue:
	change
		this.$http.get('/CDM/v1/missions')
	to
		this.$http.get('http://localhost/api/v1/missions')

- In src/components/MissionManagement.vue:
	change
		this.uri = '/CDM/v1/missions';
	to
		this.uri = 'http://localhost/api/v1/missions';


