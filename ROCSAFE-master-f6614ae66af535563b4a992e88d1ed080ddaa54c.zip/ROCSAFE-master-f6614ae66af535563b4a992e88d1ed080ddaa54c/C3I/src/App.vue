<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-app id="app">

		<!-- Main View -->
		<v-container v-if="authenticated && win.id === 0" fluid fill-height class="px-0 pt-0 pb-1">
			<mission-management :show="mission.management" :mission="mission.details" :users="items[2].items" :map-center="map.reportedCenter" :map-zoom="map.reportedZoom" @dismiss="missionManagementDismiss"></mission-management>
			<v-navigation-drawer v-model="drawer" mobile-break-point="960" fixed clipped app>
				<v-list expand>
					<v-list-group v-for="item in items" :key="item.title" :prepend-icon="item.icon" no-action>
						<v-list-tile slot="activator">
							<v-list-tile-content>
								<v-list-tile-title>{{ item.title }}</v-list-tile-title>
							</v-list-tile-content>
						</v-list-tile>
						<template v-if="item.icon === 'mdi-test-tube'">
							<v-list-tile>
								<v-btn :disabled="win.video !== null" class="mx-auto" @click="win.launchVideo()">
									Start Video
									<v-icon right>videocam</v-icon>
								</v-btn>
							</v-list-tile>
							<v-list-tile>
								<v-btn class="mx-auto" @click="win.launchWindow()">
									Launch Window
									<v-icon right>launch</v-icon>
								</v-btn>
							</v-list-tile>
							<v-list-tile>
								<v-btn :disabled="win.childWin.length === 0" class="mx-auto" @click="win.close()">
									Close Windows
									<v-icon right>close</v-icon>
								</v-btn>
							</v-list-tile>
						</template>
						<template v-else>
							<v-list-tile v-for="subItem in item.items" :key="subItem.name" @click="nav(subItem)">
								<v-list-tile-content @click="nav(subItem)">
									<v-list-tile-title>{{ subItem.name }}</v-list-tile-title>
								</v-list-tile-content>
								<v-list-tile-action v-if="typeof subItem.selected === 'boolean'">
									<v-checkbox v-model="subItem.selected"></v-checkbox>
								</v-list-tile-action>
							</v-list-tile>
						</template>
					</v-list-group>
				</v-list>
			</v-navigation-drawer>
			<v-toolbar :color="darkBackground" dark fixed clipped-left clipped-right app>
				<v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
				<v-toolbar-title class="mt-1 mx-1">
					<img src="./assets/ROCSAFE_C3I.png" height="52" alt="Logo">
				</v-toolbar-title>
				<v-btn :disabled="mission.management" flat icon @click.stop="mission.management = true">
					<v-icon>add_circle_outline</v-icon>
				</v-btn>
				<v-btn v-show="missions.length > 3" :disabled="mission.index <= 0" flat icon class="mx-1" @click="mission.index--">
					<v-icon>chevron_left</v-icon>
				</v-btn>
				<v-btn-toggle v-model="mission.selected">
					<v-btn v-for="(item, idx) in missions" v-show="idx >= mission.index && idx < mission.index + 3" :key="idx" flat class="toolbar-mission">
						<v-icon>{{ mission.icon }}</v-icon>
						<div class="caption">{{ item.name }}</div>
					</v-btn>
				</v-btn-toggle>
				<v-btn v-show="missions.length > 3" :disabled="(mission.index + 3) >= missions.length" flat icon class="mx-1" @click="mission.index++">
					<v-icon>chevron_right</v-icon>
				</v-btn>
				<v-btn-toggle v-model="map.mode" class="mx-2">
					<v-btn flat icon>
						<v-icon>location_on</v-icon>
					</v-btn>
				</v-btn-toggle>
				<v-spacer></v-spacer>
				<user-menu :user="user" :img-base="imgBase" @logout="logout"></user-menu>
			</v-toolbar>
			<v-content class="fill-height">
				<v-map-search ref="mapSearch" :value.sync="map.search" @place_changed="mapSearchChanged"></v-map-search>
				<gmap-map ref="gmap" :center="map.center" :zoom="map.zoom" :options="map.options" class="fill-height" @center_changed="mapCenterChanged" @zoom_changed="mapZoomChanged" @idle="mapIdle" @click="mapClick">
					<gmap-info-window :options="map.infoWin.options" :position="map.infoWin.position" :opened="map.infoWin.open" @closeclick="map.infoWin.open=false">
						{{ map.infoWin.content }}
					</gmap-info-window>
					<gmap-marker v-if="mission.management && mission.details === null" :position="map.reportedCenter" :label="map.centerIcon" :icon="map.nullIcon"></gmap-marker>
					<gmap-cluster :max-zoom="12">
						<gmap-marker v-for="(m, i) in map.markers.data" :key="i" :position="m.position" :draggable="map.markers.draggable" :label="m.label" :clickable="true" :animation="map.markers.animation" @click="toggleInfoWindow(m,i)" @dblclick="markerDblClick(m,i)" @dragend="markerDragged(m,$event)">
						</gmap-marker>
					</gmap-cluster>
				</gmap-map>
			</v-content>
			<v-footer :color="darkBackground" class="px-2" dark app>
				<v-spacer></v-spacer>
				<span class="caption">&copy; {{ new Date().getFullYear() }} ROCSAFE Consortium</span>
			</v-footer>
		</v-container>

		<!-- Child Windows View -->
		<v-container v-else-if="win.id !== 0" fill-height>
			<v-layout align-center>
				<v-flex class="text-xs-center">
					<div :class="darkBackground" class="pt-3 pb-2" style="border-radius:30px">
						<img src="./assets/ROCSAFE_C3I.png" height="52" alt="Logo">
					</div>
					<v-chip class="title" color="info" text-color="white">
						Window {{ win.id }}
					</v-chip>
				</v-flex>
			</v-layout>
		</v-container>

		<!-- Progress Indicator View -->
		<v-container v-else fill-height>
			<v-layout align-center>
				<v-flex class="text-xs-center">
					<v-progress-circular :size="100" :width="6" indeterminate color="amber"></v-progress-circular>
				</v-flex>
			</v-layout>
		</v-container>

	</v-app>
</template>

<script>
import authConfig from './config/keycloak.json';
import mapStyle from './config/map-style.json';
import MultiWindow from './classes/multi-window';
import {
	loaded as mapsLoaded
} from 'vue2-google-maps';
import GmapCluster from 'vue2-google-maps/dist/components/cluster';
import UserMenu from './components/UserMenu.vue';
import MissionManagement from './components/MissionManagement.vue';
import VMapSearch from './components/VMapSearch.vue';

export default {
	name: 'App',

	components: {
		'gmap-cluster': GmapCluster,
		'user-menu': UserMenu,
		'mission-management': MissionManagement,
		'v-map-search': VMapSearch
	},

	data: () => ({
		authenticated: false,
		drawer: true,
		darkBackground: 'blue darken-4',
		imgBase: 'https://rocsafe.inov.pt/img/users/',
		user: {
			uid: null,
			name: null,
			email: null,
			role: null,
			avatar: null,
			img: null
		},
		mission: {
			icon: 'mdi-target',
			index: 0,
			selected: null,
			management: false,
			details: null
		},
		missions: [],
		items: [
			{
				title: 'Missions',
				icon: 'mdi-target',
				items: []
			},
			{
				title: 'Resources',
				icon: 'mdi-file-tree',
				items: []
			},
			{
				title: 'Users',
				icon: 'mdi-account-multiple',
				items: []
			},
			{
				title: 'Test Area',
				icon: 'mdi-test-tube',
				items: []
			}
		],
		win: null,
		map: {
			center: {
				lat: 38.735086,
				lng: -9.141247
			},
			reportedCenter: null,
			zoom: 10,
			reportedZoom: null,
			options: {
				minZoom: 2,
				maxZoom: null,
				fullscreenControl: false,
				mapTypeControl: false,
				rotateControl: false,
				scaleControl: false,
				streetViewControl: false,
				zoomControl: false,
				styles: mapStyle,
				draggableCursor: null,
				gestureHandling: null
			},
			search: null,
			infoWin: {
				open: false,
				position: {
					lat: 0,
					lng: 0
				},
				options: {
					pixelOffset: {
						width: -1,
						height: -40
					}
				},
				content: null,
				currentMarker: null
			},
			mode: null,
			markers: {
				animation: null,
				draggable: true,
				data: [{
					position: {
						lat: 38.728983,
						lng: -9.142919
					},
					label: null
				}, {
					position: {
						lat: 38.752765,
						lng: -9.184777
					},
					label: null
				}, {
					position: {
						lat: 38.705139,
						lng: -9.204351
					},
					label: null
				}, {
					position: {
						lat: 38.712636,
						lng: -9.153945
					},
					label: null
				}, {
					position: {
						lat: 38.698138,
						lng: -9.200705
					},
					label: null
				}]
			},
			centerIcon: {
				fontFamily: 'Material Icons',
				fontSize: '32px',
				text: '\uE3DC',
				color: '#1976d2'
			},
			nullIcon: {
				path: '',
				scale: 0
			}
		}
	}),

	computed: {
		mapReady() {
			return this.authenticated && this.win.id === 0 && this.map.reportedCenter !== null;
		}
	},

	watch: {
		mapReady(newVal) {
			if (!newVal) {
				return;
			}
			this.$nextTick(() => {
				this.$refs.gmap.$mapPromise.then(() => {
					let map = this.$refs.gmap.$mapObject;
					map.setOptions({
						fullscreenControl: true,
						fullscreenControlOptions: {
							position: google.maps.ControlPosition.RIGHT_BOTTOM
						},
						mapTypeControl: true,
						mapTypeControlOptions: {
							style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
							position: google.maps.ControlPosition.RIGHT_TOP
						},
						zoomControl: true,
						zoomControlOptions: {
							position: google.maps.ControlPosition.RIGHT_BOTTOM
						}
					});
					map.controls[google.maps.ControlPosition.TOP_LEFT].push(this.$refs.mapSearch.$el);
				});
			});
		},
		'map.mode' (newVal) {
			if (newVal === 0) {
				this.map.markers.draggable = true;
				this.map.options.draggableCursor = 'crosshair';
				this.map.options.gestureHandling = 'none';
			} else {
				this.map.markers.draggable = false;
				this.map.options.draggableCursor = null;
				this.map.options.gestureHandling = null;
			}
		},
		drawer(newVal) {
			if (!this.map.needsResize || newVal) {
				return;
			}
			var elem = this.$el.querySelector('.navigation-drawer');
			if (elem === null) {
				return;
			}
			elem.addEventListener('transitionend', () => {
				console.log('Map: Resize');
				this.$refs.gmap.resizePreserveCenter();
				this.map.needsResize = false;
			}, {
				once: true
			});
		},
		'mission.selected' (index) {
			if (index === null) {
				return;
			}
			let location = this.missions[index].location;
			this.map.center.lat = location.center.lat;
			this.map.center.lng = location.center.lng;
			this.map.zoom = location.zoom;
			this.map.search = null;
		}
	},

	created() {
		this.win = new MultiWindow('c3i-multi-window-');
		if (this.win.id === 0) {
			console.log('Keycloak Config', authConfig);
			if (this.$isUndefined(Keycloak)) {
				alert('Failed to contact authentication server!');
				return;
			}
			this.eventIcons = [
				{ /* chemical-weapon */
					fontFamily: 'Material Design Icons',
					fontSize: '22px',
					text: '\uF13B',
					label: 'Chemical'
				},
				{ /* biohazard */
					fontFamily: 'Material Design Icons',
					fontSize: '22px',
					text: '\uF0A7',
					label: 'Biological'
				},
				{ /* radioactive */
					fontFamily: 'Material Design Icons',
					fontSize: '22px',
					text: '\uF43C',
					label: 'Radiological'
				},
				{ /* atom */
					fontFamily: 'Material Design Icons',
					fontSize: '22px',
					text: '\uF767',
					label: 'Nuclear'
				},
				{ /* bomb */
					fontFamily: 'Material Design Icons',
					fontSize: '22px',
					text: '\uF690',
					label: 'Explosive'
				}
			];
			this.map.markers.data.forEach((marker, index) => marker.label = this.eventIcons[index % this.eventIcons.length]);
			this.drawer = JSON.parse(localStorage.getItem(this.win.name + ':drawer'));
			this.map.needsResize = true;
			window.addEventListener('resize', () => {
				this.map.needsResize = true;
			});
			window.addEventListener('beforeunload', () => this.saveState());
			this.map.centerChanged = true;
			this.map.searchChanged = true;
			this.keycloak = Keycloak(authConfig);
			console.log('Keycloak', this.keycloak);
			this.keycloak.init({
				onLoad: 'login-required'
			}).success(authenticated => {
				this.authenticated = authenticated;
				console.log('Authenticated', authenticated);
				if (authenticated) {
					this.updateAuthenticationToken();
					this.getServerData();
					this.getUserProfile();
					this.win.init();
					this.win.restore();
				}
			}).error(() => {
				alert('Failed to perform authentication procedure!');
			});
		} else {
			this.win.init();
			this.win.adjust();
		}
	},

	mounted() {
		mapsLoaded.then(() => {
			this.map.maxZoomService = new google.maps.MaxZoomService();
			this.map.reportedCenter = new google.maps.LatLng(this.map.center.lat, this.map.center.lng);
			this.map.reportedZoom = this.map.zoom;
			this.map.markers.animation = google.maps.Animation.DROP;
		});
	},

	methods: {
		nav(item) {
			console.log('Selected option', item);
			if (this.$isObject(item.location) && this.$isObject(item.available)) {
				this.mission.details = item;
				this.mission.management = true;
			}
		},
		setUserAttr(prop, attr) {
			if (this.$isDefined(attr)) {
				this.user[prop] = attr[0];
			}
		},
		updateAuthenticationToken() {
			// TODO: Integrate token update procedure in the Axios plugin
			this.$http.updateToken(this.keycloak.token);
			setInterval(() => {
				this.keycloak.updateToken(25).success((refresh) => {
					if (refresh) {
						this.$http.updateToken(this.keycloak.token);
					}
				});
			}, 20000);
		},
		getUserProfile() {
			function getRole(roles) {
				const reservedRoles = ['offline_access', 'uma_authorization'];
				let role = null;
				roles.every(roleName => {
					let reserved = reservedRoles.includes(roleName);
					if (!reserved) {
						role = roleName;
					}
					return reserved;
				});
				return role;
			}
			var token = this.keycloak.tokenParsed;
			console.log('Get User Info', token);
			this.user.uid = token.preferred_username;
			this.user.avatar = this.imgBase + this.user.uid + '.jpg';
			this.user.name = token.name;
			this.user.email = token.email;
			this.user.role = getRole(token.realm_access.roles);
			this.keycloak.loadUserProfile().success(profile => {
				console.log('User Profile', profile);
				this.setUserAttr('phone', profile.attributes.phone);
			}).error(() => {
				console.warn('Failed to load user profile');
			});
		},
		getServerData() {
			this.$http.get('/auth/admin/realms/ROCSAFE/users')
				.then(response => {
					response.data.forEach(user => {
						this.items[2].items.push({
							id: user.id,
							name: user.firstName + ' ' + user.lastName
						});
					});
					this.items[2].items.sort((a, b) => {
						var nameA = a.name.toUpperCase();
						var nameB = b.name.toUpperCase();
						if (nameA < nameB) {
							return -1;
						}
						if (nameA > nameB) {
							return 1;
						}
						return 0;
					});
				});
			this.$http.get('/CDM/v1/missions')
				.then(response => {
					this.missions.length = 0;
					response.data.forEach(mission => {
						this.missions.push(mission);
					});
					this.items[0].items = this.$cloneObject(this.missions);
				});
		},
		logout() {
			console.log('Pressed Logout button', this.keycloak);
			this.keycloak.logout();
		},
		saveState() {
			localStorage.setItem(this.win.name + ':drawer', this.drawer);
		},
		mapCenterChanged(center) {
			this.map.reportedCenter = center;
			this.map.centerChanged = true;
		},
		mapZoomChanged(zoom) {
			var map = this.map;
			if (this.$isUndefined(zoom)) {
				zoom = map.reportedZoom;
			} else {
				map.reportedZoom = zoom;
			}
			// TODO: Use improved CSS selectors for zoom buttons, because the current ones
			//       only work if maps language is set to 'en'.
			map.zoomOutElem = this.$refs.gmap.$el.querySelector('button[title="Zoom out"]');
			if (map.zoomOutElem === null) {
				return;
			}
			map.zoomInElem = this.$refs.gmap.$el.querySelector('button[title="Zoom in"]');
			if (map.zoomInElem === null) {
				return;
			}
			var options = map.options;
			if (zoom <= options.minZoom) {
				console.log('Map: Reached Min Zoom:', zoom);
				map.zoomOutElem.setAttribute('disabled', '');
			} else if (options.maxZoom !== null && zoom >= options.maxZoom) {
				console.log('Map: Reached Max Zoom:', zoom);
				map.zoomInElem.setAttribute('disabled', '');
			} else {
				map.zoomOutElem.removeAttribute('disabled');
				map.zoomInElem.removeAttribute('disabled');
			}
		},
		mapIdle() {
			var map = this.map;
			map.zoom = map.reportedZoom;
			if (!map.centerChanged) {
				return;
			}
			map.centerChanged = false;
			map.maxZoomService.getMaxZoomAtLatLng(map.reportedCenter, response => {
				map.options.maxZoom = (response.status === 'OK' ? response.zoom : null);
				console.log('Map: Max Zoom:', map.options.maxZoom);
				// TODO: Replace setTimeout by mapZoomChanged call on event (which?)
				setTimeout(() => {
					this.mapZoomChanged();
				}, 50);
			});
			map.center.lat = map.reportedCenter.lat();
			map.center.lng = map.reportedCenter.lng();
			if (map.searchChanged) {
				map.searchChanged = false;
			} else {
				map.search = null;
			}
		},
		mapClick(mouseEvent) {
			if (this.map.mode !== 0) {
				return;
			}
			let marker = {
				position: {
					lat: mouseEvent.latLng.lat(),
					lng: mouseEvent.latLng.lng(),
				},
				label: null
			};
			this.map.markers.data.push(marker);
			setTimeout(() => {
				marker.label = this.eventIcons[0];
			}, 600);
		},
		mapSearchChanged(place) {
			if (!this.$isObject(place.geometry)) {
				return;
			}
			this.map.searchChanged = true;
			console.log('Map: Place:', place);
			if (this.$isObject(place.geometry.viewport)) {
				console.log('Map: Place Viewport:', place.geometry.viewport);
				this.$refs.gmap.fitBounds(place.geometry.viewport);
			} else {
				this.map.center.lat = place.geometry.location.center.lat;
				this.map.center.lng = place.geometry.location.center.lng;
				this.map.zoom = 17;
			}
		},
		toggleInfoWindow(marker, index) {
			this.map.infoWin.position = marker.position;
			this.map.infoWin.content = marker.label.label;
			// Check if its the same marker that was selected if yes toggle
			if (this.map.infoWin.currentMarker === index) {
				this.map.infoWin.open = !this.map.infoWin.open;
			}
			// If different marker set infowindow to open and reset current marker index
			else {
				this.map.infoWin.open = true;
				this.map.infoWin.currentMarker = index;
			}
		},
		markerDragged(marker, mouseEvent) {
			marker.position.lat = mouseEvent.latLng.lat();
			marker.position.lng = mouseEvent.latLng.lng();
		},
		markerDblClick(marker, index) {
			if (this.map.mode !== 0) {
				return;
			}
			this.map.markers.data.splice(index, 1);
			this.map.infoWin.open = false;
		},
		missionManagementDismiss(mission) {
			console.log('Mission Management Dismiss');
			this.mission.management = false;
			this.mission.details = null;
			let index;
			if (this.$isObject(mission)) {
				index = this.missions.findIndex(elem => elem._id === mission._id);
				if (index >= 0) {
					console.log('Update Missions - Changed Mission', index, mission);
					Object.assign(this.missions[index], mission);
					Object.assign(this.items[0].items[index], mission);
				} else {
					console.log('Update Missions - Add Mission', mission);
					this.missions.push(mission);
					this.items[0].items.push(this.$cloneObject(mission));
				}
			} else if (this.$isString(mission)) {
				console.log('Update Missions - Delete Mission', mission);
				index = this.missions.findIndex(elem => elem._id === mission);
				if (index >= 0) {
					this.missions.splice(index, 1);
					this.items[0].items.splice(index, 1);
				}
			}
		}
	}
};
</script>

<style>
html {
	overflow-y: hidden;
}
.list__tile.list__tile--link {
	height: 36px;
}
.navigation-drawer.navigation-drawer--clipped {
	padding-bottom: 36px;
}
.toolbar .btn-toggle {
	background: transparent;
	box-shadow: none;
}
.gm-style button:disabled {
	opacity: 0.5 !important;
	cursor: not-allowed !important;
}
.btn-toggle .toolbar-mission {
	height: 42px;
	width: 70px;
}
.btn-toggle .toolbar-mission .btn__content {
	display: inline-block;
}
</style>
