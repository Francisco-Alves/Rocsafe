/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import Storage from './storage';

export default class MWin {

	constructor(baseName) {
		MWin.log(`Multi-Window Class Instantiated: BaseName="${baseName}"`);
		this.baseName = baseName;
		if (window.name.indexOf(this.baseName) !== 0) {
			/* Main Window */
			this.id = 0;
		} else {
			/* Child Windows */
			this.id = window.name.slice(this.baseName.length);
		}
		this.name = this.baseName + this.id;
		this.childWin = [];
		this.video = null;
		this.storage = new Storage();
		this.isChrome = !!window.chrome && !!window.chrome.webstore;
		MWin.log('Chrome:', this.isChrome ? 'Yes' : 'No');
	}

	init() {
		MWin.log(`Init: Name="${this.name}"`);
		this.storage.set(this.name, true);
		window.addEventListener('beforeunload', evt => this.saveState(evt));
	}

	launchVideo() {
		MWin.log('Launch Video');
		var l = this.createLayout(640, 480, true);
		this.launchWindow(l);
	}

	launchWindow(layout) {
		MWin.log('Launch Window: Layout:', layout);
		var l;
		if (layout === undefined) {
			l = this.createLayout(250, 250, false);
		} else {
			l = layout;
			l.pr = window.devicePixelRatio;
		}
		var winId = this.childWin.length + 1;
		var name = this.baseName + winId;
		var win;
		if (l !== null) {
			var params;
			if (this.isChrome) {
				params = 'width=' + Math.round(l.w * l.pr) + ',height=' + Math.round(l.h * l.pr) +
					',left=' + l.x + ',top=' + l.y;
			} else {
				params = 'width=' + l.w + ',height=' + l.h + ',left=' + l.x + ',top=' + l.y;
			}
			params += ',menubar=no,toolbar=no,location=no,personalbar=no,status=no,resizable=yes,scrollbars=yes';
			MWin.log('Window Params:', params);
			var uri = l.video ? location.href + 'webrtc/client' : location.href;
			win = window.open(uri, name, params);
			MWin.log('Child Win:', win);
			if (win !== null) {
				if (l.video) {
					this.video = winId;
				}
				win.addEventListener('beforeunload', evt => this.updateChildWin(evt));
				this.childWin.push(win);
			}
		} else {
			this.childWin.push(null);
		}
	}

	restore() {
		var maxChild = this.storage.get(this.name + ':maxChild');
		MWin.log(`Restore: Stored Childs=${maxChild}`);
		if (maxChild === null) {
			return;
		}
		for (var i = 1; i <= maxChild; i++) {
			var layout = this.storage.get(this.baseName + i + ':layout');
			this.launchWindow(layout);
		}
	}

	adjust() {
		var layout = this.storage.get(this.name + ':layout');
		MWin.log('Adjust: Stored Layout:', layout);
		if (layout === null) {
			return;
		}
		var winLayout = MWin.windowLayout;
		var dx = layout.x - winLayout.x;
		var dy = layout.y - winLayout.y;
		if (dx !== 0 || dy !== 0) {
			MWin.log(`Window Position Adjust: Dx=${dx} Dy=${dy}`);
			if (this.isChrome) {
				window.moveTo(layout.x + dx, layout.y + dy);
			} else {
				window.moveBy(dx, dy);
			}
		}
		var dw = layout.w - winLayout.w;
		var dh = layout.h - winLayout.h;
		if (dw !== 0 || dh !== 0) {
			MWin.log(`Window Size Adjust: Dw=${dw} Dh=${dh}`);
			window.resizeBy(dw, dh);
		}
	}

	close() {
		MWin.log('Close');
		for (var i = 0; i < this.childWin.length; i++) {
			if (this.childWin[i] !== null) {
				this.childWin[i].close();
			}
		}
	}

	saveState() {
		MWin.log(`Save State: Name="${this.name}"`);
		this.storage.del(this.name);
		if (this.id === 0) {
			this.storage.set(this.name + ':maxChild', this.childWin.length);
			this.close();
		}
		if (this.storage.get(this.baseName + 0) === null) {
			var winLayout = MWin.windowLayout;
			this.storage.set(this.name + ':layout', winLayout);
		} else {
			this.storage.del(this.name + ':layout');
		}
	}

	updateChildWin(event) {
		var winName = event.currentTarget.name;
		MWin.log(`Update Child Windows: Source Event="${winName}"`);
		var id = Number(winName.substring(this.baseName.length));
		if (id > 0) {
			this.childWin[id - 1] = null;
			if (this.video === id) {
				this.video = null;
			}
		}
		var i;
		for (i = this.childWin.length - 1; i >= 0; i--) {
			if (this.childWin[i] !== null) {
				return;
			}
		}
		for (i = this.childWin.length; i > 0; i--) {
			this.childWin.pop();
		}
	}

	createLayout(w, h, video) {
		var winLayout = MWin.windowLayout;
		var l = {
			w: w,
			h: h,
			video: video,
			pr: window.devicePixelRatio
		};
		if (this.isChrome) {
			l.x = winLayout.x + Math.round((window.outerWidth - (l.w * l.pr)) / 2);
			l.y = winLayout.y + Math.round((window.outerHeight - (l.h * l.pr)) / 2);
		} else {
			l.x = winLayout.x + Math.round((window.outerWidth - l.w) / 2);
			l.y = winLayout.y + Math.round((window.outerHeight - l.h) / 2);
		}
		return l;
	}

	static log() {
		const LOG_PREFIX = '[MWin]';
		var args = Array.prototype.slice.call(arguments);
		args.unshift(LOG_PREFIX);
		console.log.apply(console, args);
	}

	static get windowLayout() {
		return {
			w: window.innerWidth,
			h: window.innerHeight,
			x: window.screenX,
			y: window.screenY
		};
	}

}
