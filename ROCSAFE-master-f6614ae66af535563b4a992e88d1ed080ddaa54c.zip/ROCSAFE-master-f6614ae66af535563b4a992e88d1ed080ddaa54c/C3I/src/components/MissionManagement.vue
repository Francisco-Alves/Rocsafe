<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-navigation-drawer :value="show" :disable-resize-watcher="true" :mobile-break-point="960" :width="382" fixed clipped app right>
		<v-card flat>
			<v-card-title>
				<v-toolbar dense dark color="secondary">
					<span class="title">{{ title }}</span>
					<v-spacer></v-spacer>
					<v-btn icon dark @click="$emit('dismiss')">
						<v-icon>close</v-icon>
					</v-btn>
				</v-toolbar>
			</v-card-title>
			<v-card-text>
				<v-container grid-list-md>
					<v-form ref="form" v-model="valid">
						<v-layout row wrap justify-space-between>
							<v-flex xs10>
								<v-text-field :counter="nameLength" :rules="[rules.required, rules.name]" v-model="form.name" prepend-icon="mdi-target" label="Name" required>
								</v-text-field>
							</v-flex>
							<v-flex xs2>
								<v-tooltip :open-delay="750" top>
									<v-btn slot="activator" flat icon @click="form.visible = ! form.visible">
										<v-icon :color="visibleMeta.color">{{ visibleMeta.icon }}</v-icon>
									</v-btn>
									<span> {{ visibleMeta.tooltip }} </span>
								</v-tooltip>
							</v-flex>
							<v-flex xs12 sm1 class="pt-4">
								<v-icon right>mdi-google-maps</v-icon>
							</v-flex>
							<v-flex xs12 sm4>
								<v-text-field :value="form.location.center.lat" type="Number" label="Latitude" readonly></v-text-field>
							</v-flex>
							<v-flex xs12 sm4>
								<v-text-field :value="form.location.center.lng" type="Number" label="Longitude" readonly></v-text-field>
							</v-flex>
							<v-flex xs12 sm2>
								<v-text-field :value="form.location.zoom" type="Number" label="Zoom" readonly></v-text-field>
							</v-flex>
							<v-flex xs12 sm6>
								<v-menu ref="startDate" :close-on-content-click="false" :return-value.sync="form.available.startDate" v-model="startDate" :nudge-bottom="50" transition="scale-transition">
									<v-text-field slot="activator" v-model="form.available.startDate" label="Start Date" prepend-icon="mdi-clock-start" readonly></v-text-field>
									<v-date-picker v-model="form.available.startDate" :min="startMinDate" :max="startMaxDate" no-title scrollable>
										<v-btn flat color="primary" @click="$refs.startDate.save(null)">Clear</v-btn>
										<v-spacer></v-spacer>
										<v-btn flat color="primary" @click="startDate = false">Cancel</v-btn>
										<v-btn flat color="primary" @click="$refs.startDate.save(form.available.startDate)">OK</v-btn>
									</v-date-picker>
								</v-menu>
							</v-flex>
							<v-flex xs12 sm6>
								<v-menu ref="endDate" :close-on-content-click="false" :return-value.sync="form.available.endDate" v-model="endDate" :nudge-bottom="50" transition="scale-transition">
									<v-text-field slot="activator" v-model="form.available.endDate" label="End Date" prepend-icon="mdi-clock-end" readonly></v-text-field>
									<v-date-picker v-model="form.available.endDate" :min="endMinDate" no-title scrollable>
										<v-btn flat color="primary" @click="$refs.endDate.save(null)">Clear</v-btn>
										<v-spacer></v-spacer>
										<v-btn flat color="primary" @click="endDate = false">Cancel</v-btn>
										<v-btn flat color="primary" @click="$refs.endDate.save(form.available.endDate)">OK</v-btn>
									</v-date-picker>
								</v-menu>
							</v-flex>
							<v-flex xs12>
								<v-text-field :rows="3" :counter="descLength" :rules="[rules.desc]" v-model="form.description" prepend-icon="mdi-comment-text" multi-line no-resize label="Description">
								</v-text-field>
							</v-flex>
							<template v-if="mission">
								<v-flex xs12>
									<v-text-field v-model="form.user" label="Created By" prepend-icon="perm_contact_calendar" readonly></v-text-field>
								</v-flex>
								<v-flex xs12>
									<v-text-field v-model="form.createdAt" label="Created At" prepend-icon="mdi-calendar-plus" readonly></v-text-field>
								</v-flex>
								<v-flex xs12>
									<v-text-field v-model="form.updatedAt" label="Updated At" prepend-icon="mdi-calendar-edit" readonly></v-text-field>
								</v-flex>
							</template>
						</v-layout>
					</v-form>
				</v-container>
			</v-card-text>
			<v-card-actions class="pa-3">
				<v-layout justify-space-around>
					<v-btn v-if="mission === null" :disabled="!valid" :loading="saving" color="primary" @click.native="save">
						Save
						<v-icon right>backup</v-icon>
					</v-btn>
					<template v-else>
						<v-btn :loading="saving" color="error" @click.native="remove">
							Delete
							<v-icon right>delete</v-icon>
						</v-btn>
						<v-btn :disabled="!valid" :loading="saving" color="primary" @click.native="update">
							Update
							<v-icon right>backup</v-icon>
						</v-btn>
					</template>
				</v-layout>
			</v-card-actions>
		</v-card>
	</v-navigation-drawer>
</template>

<script>
export default {
	props: {
		'show': {
			type: Boolean,
			required: true
		},
		'mission': {
			type: Object,
			default: null
		},
		'users': {
			type: Array,
			default: null
		},
		'mapCenter': {
			type: Object,
			required: true
		},
		'mapZoom': {
			type: Number,
			required: true
		}
	},

	data() {
		return {
			form: {
				name: null,
				visible: true,
				location: {
					center: {
						lat: null,
						lng: null
					},
					zoom: null
				},
				available: {
					startDate: null,
					endDate: null
				},
				description: null
			},
			map: {
				location: {
					center: {
						lat: null,
						lng: null
					},
					zoom: null
				}
			},
			startDate: false,
			endDate: false,
			valid: false,
			saving: false,
			visibleMeta: {
				icon: null,
				color: null,
				tooltip: null
			},
			accuracy: 7,
			nameLength: 10,
			descLength: 140,
			rules: {
				required: v => v !== null && v.trim().length > 0 || 'Required',
				name: v => v === null || v.length <= this.nameLength || `Must be less than ${this.nameLength} characters`,
				desc: v => v === null || v.length <= this.descLength || `Must be less than ${this.descLength} characters`
			}
		};
	},

	computed: {
		startMinDate() {
			let now = new Date();
			let date = now.toJSON().split('T')[0];
			return date;
		},
		startMaxDate() {
			return this.form.available.endDate;
		},
		endMinDate() {
			return (this.form.available.startDate === null ? this.startMinDate : this.form.available.startDate);
		}
	},

	watch: {
		mission: {
			immediate: true,
			handler(v) {
				if (v === null) {
					this.title = 'New Mission';
					this.cleanForm();
					return;
				}

				function timestampFormat(date) {
					return date.getUTCFullYear().toString().padStart(4, '0') + '-' +
						((date.getUTCMonth() + 1).toString().padStart(2, '0')) + '-' +
						date.getUTCDate().toString().padStart(2, '0') + ' ' +
						date.getUTCHours().toString().padStart(2, '0') + ':' +
						date.getUTCMinutes().toString().padStart(2, '0') + ':' +
						date.getUTCSeconds().toString().padStart(2, '0') + ' UTC';
				}

				function getUserName(users, id) {
					if (users === null) {
						return null;
					}
					let found = users.find(elem => elem.id === id);
					if (found === undefined) {
						return null;
					}
					return found.name;
				}

				this.title = 'Manage Mission';
				this.form.name = v.name;
				this.form.visible = v.visible;
				this.form.location.center.lat = v.location.center.lat;
				this.form.location.center.lng = v.location.center.lng;
				this.form.location.zoom = v.location.zoom;
				this.form.available.startDate = this.$isString(v.available.startDate) ? v.available.startDate.split('T')[0] : null;
				this.form.available.endDate = this.$isString(v.available.endDate) ? v.available.endDate.split('T')[0] : null;
				this.form.description = v.description;
				this.form.user = getUserName(this.users, v.user);
				this.form.createdAt = timestampFormat(new Date(v.createdAt));
				this.form.updatedAt = timestampFormat(new Date(v.updatedAt));
			}
		},
		mapCenter: {
			immediate: true,
			handler(value) {
				if (value !== null) {
					this.map.location.center.lat = value.lat().toFixed(this.accuracy);
					this.map.location.center.lng = value.lng().toFixed(this.accuracy);
				}
				if (this.mission === null) {
					this.form.location.center.lat = this.map.location.center.lat;
					this.form.location.center.lng = this.map.location.center.lng;
				}
			}
		},
		mapZoom: {
			immediate: true,
			handler(value) {
				this.map.location.zoom = value;
				if (this.mission === null) {
					this.form.location.zoom = this.map.location.zoom;
				}
			}
		},
		'form.visible': {
			immediate: true,
			handler(value) {
				let obj = this.visibleMeta;
				if (value) {
					obj.icon = 'visibility';
					obj.color = 'grey darken-1';
					obj.tooltip = 'Visible';
				} else {
					obj.icon = 'visibility_off';
					obj.color = 'grey';
					obj.tooltip = 'Not Visible';
				}
			}
		}
	},

	created() {
		this.uri = '/CDM/v1/missions';
	},

	methods: {
		save() {
			let data = this.$cloneObject(this.form);
			delete data.user;
			delete data.createdAt;
			delete data.updatedAt;
			console.log('Request to create mission', data);
			this.saving = true;
			this.$http.post(this.uri, data)
				.then(response => {
					console.log('Mission created', response.data);
					this.saving = false;
					this.$emit('dismiss', response.data);

				})
				.catch(error => {
					this.saving = false;
					this.errorHandler(error);
				});
		},
		update() {
			let data = this.$cloneObject(this.form);
			delete data.user;
			delete data.createdAt;
			delete data.updatedAt;
			console.log('Request to update mission', this.mission._id, data);
			this.saving = true;
			this.$http.put(this.uri + '/' + this.mission._id, data)
				.then(response => {
					console.log('Mission updated', response.data);
					this.saving = false;
					this.$emit('dismiss', response.data);
				})
				.catch(error => {
					this.saving = false;
					this.errorHandler(error);
				});
		},
		remove() {
			console.log('Request to delete mission', this.mission._id);
			this.saving = true;
			this.$http.delete(this.uri + '/' + this.mission._id)
				.then(response => {
					console.log('Mission deleted', response);
					this.saving = false;
					this.$emit('dismiss', this.mission._id);
				})
				.catch(error => {
					this.saving = false;
					this.errorHandler(error);
				});
		},
		cleanForm() {
			this.$nullifyObject(this.form);
			this.form.visible = true;
			this.form.location.center.lat = this.map.location.center.lat;
			this.form.location.center.lng = this.map.location.center.lng;
			this.form.location.zoom = this.map.location.zoom;
		},
		errorHandler(error) {
			if (this.$isDefined(error.response)) {
				// The request was made and the server responded with a status code
				// that falls out of the range of 2xx
				console.warn('ERROR: Data:', error.response.data);
				console.warn('ERROR: Status:', error.response.status);
				console.warn('ERROR: Headers:', error.response.headers);
			} else if (this.$isDefined(error.request)) {
				// The request was made but no response was received
				console.warn('ERROR: Request', error.request);
			} else {
				// Something happened in setting up the request that triggered an Error
				console.warn('ERROR: Message', error.message);
			}
		}
	}
};
</script>

<style>
</style>
