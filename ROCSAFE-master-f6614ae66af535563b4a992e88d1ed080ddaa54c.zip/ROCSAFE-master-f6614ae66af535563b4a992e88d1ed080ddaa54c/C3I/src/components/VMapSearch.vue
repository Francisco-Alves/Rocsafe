<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-toolbar absolute dense floating class="my-2 extend">
		<v-text-field ref="textInput" :value="text" :placeholder="placeholder" prepend-icon="search" hide-details single-line clearable class="pl-2 pr-3"></v-text-field>
	</v-toolbar>
</template>

<script>
import {
	loaded
} from 'vue2-google-maps';

export default {
	props: {
		value: {
			type: String,
			default: null
		},
		placeholder: {
			type: String,
			default: 'Search Places'
		}
	},

	computed: {
		text: {
			get() {
				return this.value;
			},
			set(newValue) {
				this.$emit('update:value', newValue);
			}
		}
	},

	mounted() {
		console.log('VMapSearch: Mounted');
		loaded.then(() => {
			if (!this.$isObject(google.maps.places)) {
				throw new Error('Places library is unavailable. Did you add \'places\' to libraries when loading Google Maps?');
			}
			var elems = this.$refs.textInput.$el.getElementsByTagName('input');
			this.autocomplete = new google.maps.places.Autocomplete(elems[0], {
				types: ['(regions)']
			});
			this.autocomplete.addListener('place_changed', () => {
				let place = this.autocomplete.getPlace();
				if (this.$isString(place.formatted_address)) {
					this.text = place.formatted_address;
				}
				this.$emit('place_changed', place);
			});
		});
	}
};
</script>

<style>
.pac-item {
	font-family: Roboto, sans-serif;
	font-size: 14px;
}
.pac-item-query {
	font-size: 16px;
}
@media (min-width: 1281px) {
	.toolbar.extend {
		width: 480px;
	}
}
@media (max-width: 1280px) {
	.toolbar.extend {
		width: 33%;
	}
}
@media (max-width: 600px) {
	.toolbar.extend {
		width: 50%;
	}
}
.toolbar.extend .toolbar__content {
	width: 100%;
}
</style>
