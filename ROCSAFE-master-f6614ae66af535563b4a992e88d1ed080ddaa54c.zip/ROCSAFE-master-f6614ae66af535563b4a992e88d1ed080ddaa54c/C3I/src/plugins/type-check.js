/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

export default {
	install: function (Vue) {
		Vue.prototype.$isUndefined = value => typeof value === 'undefined';

		Vue.prototype.$isDefined = value => typeof value !== 'undefined';

		Vue.prototype.$isObject = value => value !== null && typeof value === 'object';

		Vue.prototype.$isString = value => typeof value === 'string';

		Vue.prototype.$isNumber = value => typeof value === 'number';

		Vue.prototype.$isDate = value => Object.prototype.toString.call(value) === '[object Date]';

		Vue.prototype.$isArray = arr => Array.isArray(arr) || arr instanceof Array;

		Vue.prototype.$isFunction = value => typeof value === 'function';
	}
};
