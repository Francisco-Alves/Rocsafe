# NODEJS Kafka Weather producer/consumer

## Contents

This demo is a Nodejs demo to create a demo app for the openweathermap kafka
producer and consumer.

## Requirements

* Nodejs 
* node package manager (npm) 
* Openweathermap API key
	