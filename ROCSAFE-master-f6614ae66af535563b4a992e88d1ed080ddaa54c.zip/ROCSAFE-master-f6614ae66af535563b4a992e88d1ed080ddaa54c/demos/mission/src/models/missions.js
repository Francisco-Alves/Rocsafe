/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

var	mongoose = require('mongoose');

var Schema = mongoose.Schema;

mongoose.Promise = global.Promise;

var missionSchema = new Schema({
	name: {
		type: String,
		required: true,
		unique: 'There already exists a mission with name "{VALUE}"'
	},
	description: {
		type: String,
		default: ''
	},
	user: {
		type: String,
		required: true
	},
	location: {
		center: {
			lat: {
				type: Number,
				required: true
			},
			lng: {
				type: Number,
				required: true
			}
		},
		zoom: {
			type: Number,
			required: true
		}
	},
	visible: {
		type: Boolean,
		default: true
	},
	available: {
		startDate: {
			type: Date
		},
		endDate: {
			type: Date
		}
	}
},{
	timestamps: true
});

var missionModel = mongoose.model('mission', missionSchema, 'missions');

var createMission = function(mission) {
	return new Promise(function(resolve, reject) {
		if (mission.hasOwnProperty('createdAt')) {
			delete mission.createdAt;
		}
		if (mission.hasOwnProperty('updatedAt')) {
			delete mission.updatedAt;
		}
		missionModel.create(mission, function (err, mission) {
			if (err) {
				reject(err);
			} else {
				mission.id = mission._id;
				delete mission.__v;
				delete mission._id;
				resolve(mission);
			}
		});
	});
};

var readMission = function(id) {
	return new Promise(function(resolve, reject) {
		if (id !== undefined) {
			missionModel.findOne({_id:id}, {__v:0}, function (err, mission) {
				if (err) {
					reject(err);
				} else {
					resolve(mission);
				}
			});	
		} else {
			missionModel.find({}, {__v:0}, function (err, missions) {
				if (err) {
					reject(err);
				} else {
					resolve(missions);
				}
			});	
		}
	});
};

var updateMission = function(id, mission) {
	return new Promise(function(resolve, reject) {
		if (mission.hasOwnProperty('createdAt')) {
			delete mission.createdAt;
		}
		if (mission.hasOwnProperty('updatedAt')) {
			delete mission.updatedAt;
		}
		missionModel.findByIdAndUpdate(id, {$set: mission}, {new: true}, function (err, missionRes) {
			if (err) {
				reject(err);
			} else {
				missionRes.id = missionRes._id;
				delete missionRes.__v;
				delete missionRes._id;
				resolve(missionRes);
			}
		});
	});
};

var deleteMission = function(id) {
	return new Promise(function(resolve, reject) {
		missionModel.remove({_id: id}, function (err, missionRes) {
			if (err) {
				reject(err);
			} else {
				resolve(missionRes);
			}
		});
	});
};

module.exports = {
	createMission: createMission,
	readMission: readMission,
	updateMission: updateMission,
	deleteMission: deleteMission
};
