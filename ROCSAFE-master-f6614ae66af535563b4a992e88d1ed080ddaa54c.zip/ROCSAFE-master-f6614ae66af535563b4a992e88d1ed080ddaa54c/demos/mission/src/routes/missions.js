/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
var Mission = require('../models/missions');

module.exports = function (app) {
	// Create
	app.post('/v1/missions', app.keycloak.protect(), function (req, res) {
		var mission = req.body;
		mission.user = req.kauth.grant.access_token.content.sub;
		Mission.createMission(mission).
			then(function (mission) {
				res.json(mission);
			}).catch(function (err) {
				var errorMsg = {
					error : 2000,
					developer : {
						text: err.errors.name.name + ' - ' + err.errors.name.kind,
						data: err
					},
					message: err.errors.name.message
				};
				// 2000 - The server failed to fulfil an apparently valid request
				res.status(400).send(errorMsg);
			});
	});

	// Read mission
	app.get('/v1/missions/:id?', app.keycloak.protect(), function (req, res) {
		Mission.readMission(req.params.id).
			then(function (missions) {
				res.json(missions);
			}).catch(function (err) {
				var errorMsg = {
					error : 2000,
					developer : {
						text: 'Cannot get mission with name "' + req.params.id + '" ',
						data: err
					},
					message: 'Unknown mission ("' + req.params.id + '")'
				};
				res.status(404).send(errorMsg);
			});
	});

	app.put('/v1/missions/:id', app.keycloak.protect(), function (req, res) {
		Mission.updateMission(req.params.id, req.body).
			then(function (mission) {
				res.json(mission);
			}).catch(function (err) {
				var errorMsg = {
					error : 2000,
					developer : {
						text: err.errors.name.name + ' - ' + err.errors.name.kind,
						data: err
					},
					message: err.errors.name.message
				};
				// 2000 - The server failed to fulfil an apparently valid request
				res.status(400).send(errorMsg);
			});
	});
	app.delete('/v1/missions/:id', app.keycloak.protect(), function (req, res) {
		Mission.deleteMission(req.params.id).
			then(function () {
				res.status(200).end();
			}).catch(function (err) {
				var errorMsg = {
					error : 2000,
					developer : {
						text: err.errors.name.name + ' - ' + err.errors.name.kind,
						data: err
					},
					message: err.errors.name.message
				};
				// 2000 - The server failed to fulfil an apparently valid request
				res.status(400).send(errorMsg);
			});
	});
};
