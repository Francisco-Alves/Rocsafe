/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

require('console-stamp')(console, 'yyyy-mm-dd HH:MM:ss.l');

const settings = require('./settings');
require('util');

const baseUri = settings.server.baseUri;

var Keycloak = require('keycloak-connect');
require('jsonwebtoken');
var express = require('express');
var session = require('express-session');

var kcUtils = require('./keycloak-utils');

var app = express();

var server = app.listen(settings.server.port, function () {
	var host = server.address().address;
	var port = server.address().port;
	console.log('Example app listening at http://%s:%s%s', host, port, baseUri);
});

// A normal un-protected public URL.
app.get(baseUri + '/', function (req, res) {
	res.send('Working');
});

// Create a session-store to be used by both the express-session
// middleware and the keycloak middleware.
var memoryStore = new session.MemoryStore();

app.use(session({
	secret: 'mySecret',
	resave: false,
	saveUninitialized: true,
	store: memoryStore
}));

// Provide the session store to the Keycloak so that sessions
// can be invalidated from the Keycloak console callback.
//
// Additional configuration is read from keycloak.json file
// installed from the Keycloak web console.
var keycloak = new Keycloak({
	store: memoryStore
});

// Install the Keycloak middleware.
//
// Specifies that the user-accessible application URL to
// logout should be mounted at /logout
//
// Specifies that Keycloak console callbacks should target the
// root URL.  Various permutations, such as /k_logout will ultimately
// be appended to the admin URL.
app.use(keycloak.middleware({
	logout: baseUri + '/logout'
}));

app.get(baseUri + '/protect', keycloak.protect(), function (req, res) {
	kcUtils.getAccountInfo(req.kauth).then(function (data) {
		res.json(data);
	}).catch(function (err) {
		res.status(503).send(err);
	});
});

var getMissionRoles = function (token, request) {
	console.log('TODO: Get mission roles', token, request);
	return true;
};

app.get(baseUri + '/mission/:mission_id', keycloak.protect(getMissionRoles), function (req, res) {
	// Get the userinfo profile from Keycloak REST-API via keycloak-utils
	kcUtils.getAccountInfo(req.kauth).then(function (data) {
		res.json(data);
	}).catch(function (err) {
		res.status(503).send(err);
	});
});
