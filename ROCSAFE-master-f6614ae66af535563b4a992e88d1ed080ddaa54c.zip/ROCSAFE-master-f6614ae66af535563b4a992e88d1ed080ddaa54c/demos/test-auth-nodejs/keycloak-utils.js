/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/
/*
 * This file contains general utilities/additions for the keycloack connector.
 */

const url = require('url');
var http = require('http');
var https = require('https');

/**
 * getAccountInfo:  Return a promise to the user profile of the authenticated user
 * @param auth: The authentication tokens from the keycloak authentication.
 */
exports.getAccountInfo = function (auth) {
	return new Promise(function (resolve, reject) {
		var port = auth.grant.access_token.content.iss.toLowerCase().startsWith('https://') ? https : http;

		var options = url.parse(auth.grant.access_token.content.iss + '/account');
		options.method = 'GET';
		options.headers = {
			'Content-Type': 'application/json',
			'Authorization': 'Bearer ' + auth.grant.access_token.token
		};

		var req = port.request(options, function (res) {
			var output = '';
			console.log(options.host + ':' + res.statusCode);
			res.setEncoding('utf8');

			res.on('data', function (chunk) {
				output += chunk;
			});

			res.on('end', function () {
				var obj = JSON.parse(output);
				resolve(obj);
			});
		});

		req.on('error', function (err) {
			reject(err);
		});
		req.end();
	});
};
