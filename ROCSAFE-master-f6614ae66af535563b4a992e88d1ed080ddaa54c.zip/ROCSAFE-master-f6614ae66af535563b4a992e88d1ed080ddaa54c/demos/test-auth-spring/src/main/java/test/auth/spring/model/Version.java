package test.auth.spring.model;

public class Version {
	
	public String name;
	public String version; 
	public String URI; 
	
	

}
