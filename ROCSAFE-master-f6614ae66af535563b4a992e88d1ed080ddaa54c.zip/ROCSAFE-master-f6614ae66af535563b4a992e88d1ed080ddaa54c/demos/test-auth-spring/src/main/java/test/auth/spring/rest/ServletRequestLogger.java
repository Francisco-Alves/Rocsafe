package test.auth.spring.rest;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener; 
import javax.servlet.http.HttpServletRequest; 

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger; 
 
@WebListener
public class ServletRequestLogger  implements ServletRequestListener{
 
	Logger log = LogManager.getLogger(ServletRequestLogger.class);
	
	@Override
	public void requestDestroyed(ServletRequestEvent event) {
	}

	@Override
	public void requestInitialized(ServletRequestEvent event) {

	    ServletContext context = event.getServletContext();
	    ServletRequest request = event.getServletRequest();

	    // HttpServletRequest extends ServletRequest so .. 
	    if(request instanceof HttpServletRequest) {
	    	HttpServletRequest httpRequest =(HttpServletRequest) request;
			log.info("======================");
	    	log.info("Request Info :  ");
			log.info("======================"); 
			log.info("IP: "+ httpRequest.getRemoteAddr());
			log.info("Server name: "+ httpRequest.getServerName());
			log.info("Method Path: "+ httpRequest.getMethod());
			log.info("Requested URI: "+ httpRequest.getRequestURI());
	    }
		
	}

}
