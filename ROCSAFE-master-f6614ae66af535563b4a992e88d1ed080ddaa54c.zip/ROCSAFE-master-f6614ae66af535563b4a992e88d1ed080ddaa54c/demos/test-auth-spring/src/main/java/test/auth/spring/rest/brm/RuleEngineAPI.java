package test.auth.spring.rest.brm;
 
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import test.auth.spring.rest.API;

@RestController
@RequestMapping
public class RuleEngineAPI extends API {
	
		@GetMapping
		public String getRuleEngine() {
			return "Rule Engine should be placed instead of this";
		}
}
