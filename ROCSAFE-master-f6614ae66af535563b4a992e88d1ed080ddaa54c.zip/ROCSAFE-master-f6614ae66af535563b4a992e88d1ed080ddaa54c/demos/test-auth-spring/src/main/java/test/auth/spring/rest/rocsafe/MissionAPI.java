/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                       $
 *----------------------------------------------------------------------------*/
package test.auth.spring.rest.rocsafe;
 

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import test.auth.spring.model.Mission; 
import test.auth.spring.rest.*;
import test.auth.spring.services.MissionService;

@RestController
@RequestMapping
public class MissionAPI extends API {
	/**
	 * Logger 
	 */
	Logger log = LogManager.getLogger(MissionAPI.class);
	
	@Autowired 
	MissionService missionsSvc;

	
	/**
	 * Lists summaries of missions
	 * 
	 * @return
	 */
	@GetMapping("/v{version}/missions/")
	public List<Mission> getMissions() {
		return this.missionsSvc.getMissionsList();
	}

	/**
	 * Creates a new Mission
	 */
	@PostMapping("/v{version}/missions/")
	public Mission createAgent(@RequestBody Mission missionBody) {
		return this.missionsSvc.createMission(missionBody);
	}

	/**
	 * List details
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping("/v{version}/missions/{mission_id}")
	public Mission getMissionDetails(@PathVariable("mission_id") int id) {
		Mission m = this.missionsSvc.getMission(id);
		return m;
	}

	/**
	 * Update a mission
	 * 
	 * @param missionBody
	 * @param id
	 * @return
	 */
	@PutMapping("/v{version}/missions/{mission_id}")
	public Mission updateMission(@RequestBody Mission missionBody, @PathVariable("mission_id") int id) {	
		return this.missionsSvc.updateMission(missionBody, id);
	}
	
	/** 
	 * Delete a mission 
	 * 
	 * @param id
	 * @return
	 */
	@DeleteMapping("/v{version}/missions/{mission_id}")
	public Mission deleteMission(@PathVariable("mission_id") int id) {
		return this.missionsSvc.deleteMission(id);
	}
}
