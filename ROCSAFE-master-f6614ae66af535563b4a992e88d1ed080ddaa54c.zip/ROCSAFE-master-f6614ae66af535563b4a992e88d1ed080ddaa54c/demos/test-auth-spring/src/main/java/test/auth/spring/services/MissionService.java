package test.auth.spring.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import test.auth.spring.model.Mission; 

@Service
public class MissionService {
	
	/*
	 * Logger
	 */
	Logger log = LogManager.getLogger(MissionService.class);
	
	/**
	 * All missions should be loaded in the beginning.
	 */
	List<Mission> missions;
	
	public MissionService() {
		setMissionsData();
	}

	/**
	 * General Constructor.
	 */
	private void setMissionsData() {
		this.missions = new ArrayList<Mission>();
		this.missions.add(new Mission(1, "alfa"));
		this.missions.add(new Mission(2, "beta"));
		this.missions.add(new Mission(3, "gamma"));
		this.missions.add(new Mission(4, "delta"));
		this.missions.add(new Mission(5, "epsilon"));
		this.missions.add(new Mission(6, "vou"));
		this.missions.add(new Mission(7, "zeta"));
		this.missions.add(new Mission(8, "eta"));
		this.missions.add(new Mission(9, "theta"));
		this.missions.add(new Mission(10, "iota"));
		this.missions.add(new Mission(20, "keppa"));
		this.missions.add(new Mission(30, "lambda"));
		this.missions.add(new Mission(40, "mu"));
		this.missions.add(new Mission(50, "nu"));
		this.missions.add(new Mission(60, "xi"));
		this.missions.add(new Mission(70, "omicron"));
		this.missions.add(new Mission(80, "pi"));
		this.missions.add(new Mission(90, "koppa"));
		this.missions.add(new Mission(100, "rho"));
	}

	// --------------------------------------------------------------------------
	// set and get Methods
	// --------------------------------------------------------------------------
	public Mission getMission(int id ){ 

		Mission requestedMission = new Mission();
		if(id <0) {
			log.warn("Id provided for a mission is less than 0 ");
		}
		for(Mission mission: this.missions) {
			if(mission.id == id) {
				requestedMission.setId(mission.id);
				requestedMission.setName(mission.name);
				break;
			}
		}
		return requestedMission;
	}

	public List<Mission> getMissionsList(){
		return missions;
	}
	
	public Mission updateMission(Mission mission,int id) {
		Mission m = getMission(id);
		m.setName(mission.getName());
		return m;
	}
	
	public Mission deleteMission(int id) {
		Mission m = getMission(id);
		Mission mCopy = new Mission();
		mCopy.setId(m.getId());
		mCopy.setName(m.getName());
		this.missions.remove(m);
		return mCopy;
	}

	public Mission createMission(Mission missionBody) {
	    Mission m = missionBody;
	    this.missions.add(m);
		return m;
	}
}
