## Build Setup

# Install dependencies
npm install

# Run server
npm start
