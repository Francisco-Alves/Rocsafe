/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import Vue from 'vue';

import {
	Button,
	MessageBox,
	Select,
	Tooltip,
	Option
} from 'element-ui';

import App from './App.vue';

Vue.use(Button);
Vue.use(Select);
Vue.use(Tooltip);
Vue.use(Option);

Vue.prototype.$msgbox = MessageBox;
Vue.prototype.$alert = MessageBox.alert;
Vue.prototype.$confirm = MessageBox.confirm;
Vue.prototype.$prompt = MessageBox.prompt;

new Vue({
	el: '#app',
	render: h => h(App)
});
