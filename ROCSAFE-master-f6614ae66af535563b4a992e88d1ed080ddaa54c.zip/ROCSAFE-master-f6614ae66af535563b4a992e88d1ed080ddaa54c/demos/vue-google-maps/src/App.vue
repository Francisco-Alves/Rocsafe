<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<gmap-map :center="map.center" :zoom="map.zoom" :options="map.options" @center_changed="mapCenterChanged" @zoom_changed="mapZoomChanged" @idle="mapIdle">
	</gmap-map>
</template>

<script>
import {
	loaded as mapsLoaded
} from 'vue2-google-maps';

export default {
	name: 'App',

	data() {
		return {
			map: {
				center: {
					lat: 38.735086,
					lng: -9.141247
				},
				zoom: 10,
				options: {
					minZoom: 2,
					maxZoom: null,
					streetViewControl: false
				}
			}
		};
	},

	mounted() {
		console.log('App: Mounted');
		mapsLoaded.then(() => {
			console.log('Map: Loaded');
			this.map.reportedCenter = new google.maps.LatLng(this.map.center.lat, this.map.center.lng);
			this.map.reportedZoom = this.map.zoom;
			this.map.centerChanged = true;
		});
	},

	methods: {
		mapCenterChanged(center) {
			this.map.reportedCenter = center;
			this.map.centerChanged = true;
		},
		mapZoomChanged(zoom) {
			this.map.reportedZoom = zoom;
			console.log('Map: Zoom:', this.map.reportedZoom);
		},
		mapIdle() {
			if (!this.map.centerChanged) return;
			this.map.centerChanged = false;
			console.log('Map: Center: (', this.map.reportedCenter.lat(), ',', this.map.reportedCenter.lng(), ')');
		}
	}
};
</script>

<style>
html,
body,
.vue-map-container {
	height: 100%;
}
body {
	margin: 0;
}
</style>
