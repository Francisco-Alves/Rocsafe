/*------------------------------------------------------------------------------
 * Copyright (C) 2017-2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

new Vue({
	el: '#app',
	data: {
		screenW: null,
		screenH: null,
		screenX: null,
		screenY: null,
		zoom: null
	},
	created: function () {
		this.handleWindowResize({
			target: window
		});
		this.handleWindowPosition();
		window.addEventListener('resize', this.handleWindowResize);
		this.interval = setInterval(this.handleWindowPosition, 250);
	},
	beforeDestroy: function () {
		window.removeEventListener('resize', this.handleWindowResize);
		clearInterval(this.interval);
	},
	methods: {
		handleWindowResize: function (event) {
			this.screenW = event.target.innerWidth;
			this.screenH = event.target.innerHeight;
			this.zoom = Math.round(event.target.devicePixelRatio * 100);
		},
		handleWindowPosition: function () {
			this.screenX = window.screenX;
			this.screenY = window.screenY;
		}
	}
});
