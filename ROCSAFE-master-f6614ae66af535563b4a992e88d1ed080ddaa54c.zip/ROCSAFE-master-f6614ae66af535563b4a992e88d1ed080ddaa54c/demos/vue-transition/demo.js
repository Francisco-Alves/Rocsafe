/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

new Vue({
	el: '#app',
	data: {
		transition: false,
		items: [-2, -1, 0, 1, 2]
	},
	methods: {
		right: function () {
			this.transition = true;
			this.items.push(this.items[this.items.length - 1] + 1);
			this.items.shift();
		},
		left: function () {
			this.transition = true;
			this.items.unshift(this.items[0] - 1);
			this.items.pop();
		}
	}
});
