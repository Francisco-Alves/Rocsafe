<!--
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 * $Id$
 -->

<template>
	<v-app>
		<v-container fluid class="pa-0">
			<v-content class="fill-height">
				<v-map-search ref="mapSearch" :value.sync="map.search" @place_changed="mapSearchChanged"></v-map-search>
				<gmap-map ref="gmap" :center="map.center" :zoom="map.zoom" :options="map.options" class="fill-height" @center_changed="mapCenterChanged" @zoom_changed="mapZoomChanged" @idle="mapIdle">
				</gmap-map>
			</v-content>
		</v-container>
	</v-app>
</template>

<script>
import mapStyle from './config/map-style.json';
import {
	loaded as mapsLoaded
} from 'vue2-google-maps';
import VMapSearch from './components/VMapSearch.vue';

export default {
	name: 'App',

	components: {
		'v-map-search': VMapSearch
	},

	data() {
		return {
			map: {
				center: {
					lat: 38.735086,
					lng: -9.141247
				},
				zoom: 10,
				options: {
					minZoom: 2,
					maxZoom: null,
					fullscreenControl: false,
					mapTypeControl: false,
					rotateControl: false,
					scaleControl: false,
					streetViewControl: false,
					zoomControl: false,
					styles: mapStyle
				},
				search: null
			}
		};
	},

	mounted() {
		console.log('App: Mounted');
		mapsLoaded.then(() => {
			console.log('Map: Loaded');
			var map = this.map;
			map.maxZoomService = new google.maps.MaxZoomService();
			map.reportedCenter = new google.maps.LatLng(map.center.lat, map.center.lng);
			map.reportedZoom = map.zoom;
			map.centerChanged = true;
			map.searchChanged = true;
			this.$refs.gmap.$mapPromise.then(() => {
				console.log('Map: Created');
				let mapObj = this.$refs.gmap.$mapObject;
				mapObj.setOptions({
					fullscreenControl: true,
					fullscreenControlOptions: {
						position: google.maps.ControlPosition.RIGHT_BOTTOM
					},
					mapTypeControl: true,
					mapTypeControlOptions: {
						style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
						position: google.maps.ControlPosition.RIGHT_TOP
					},
					zoomControl: true,
					zoomControlOptions: {
						position: google.maps.ControlPosition.RIGHT_BOTTOM
					}
				});
				mapObj.controls[google.maps.ControlPosition.TOP_LEFT].push(this.$refs.mapSearch.$el);
			});
		});
	},

	methods: {
		mapCenterChanged(center) {
			this.map.reportedCenter = center;
			this.map.centerChanged = true;
		},
		mapZoomChanged(zoom) {
			this.map.reportedZoom = zoom;
			console.log('Map: Zoom:', this.map.reportedZoom);
			this.updateZoomButtons();
		},
		mapIdle() {
			var map = this.map;
			if (!map.centerChanged) return;
			map.centerChanged = false;
			console.log('Map: Center: (', map.reportedCenter.lat(), ',', map.reportedCenter.lng(), ')');
			map.maxZoomService.getMaxZoomAtLatLng(map.reportedCenter, response => {
				if (response.status === 'OK') {
					map.options.maxZoom = response.zoom;
				} else {
					map.options.maxZoom = null;
					map.centerChanged = true;
				}
				console.log('Map: Max Zoom:', map.options.maxZoom);
				// TODO: Replace setTimeout by updateZoomButtons call on event (which?)
				setTimeout(() => {
					this.updateZoomButtons();
				}, 50);
			});
			if (map.searchChanged) {
				map.searchChanged = false;
			} else {
				map.search = null;
			}
		},
		updateZoomButtons() {
			var zoomOutElem = this.$refs.gmap.$el.querySelector('button[title="Zoom out"]');
			if (zoomOutElem === null) return;
			var zoomInElem = this.$refs.gmap.$el.querySelector('button[title="Zoom in"]');
			if (zoomInElem === null) return;
			var map = this.map;
			var options = map.options;
			if (map.reportedZoom <= options.minZoom) {
				console.log('Map: Reached Min Zoom:', map.reportedZoom);
				zoomOutElem.setAttribute('disabled', '');
			} else if (options.maxZoom !== null && map.reportedZoom >= options.maxZoom) {
				console.log('Map: Reached Max Zoom:', map.reportedZoom);
				zoomInElem.setAttribute('disabled', '');
			} else {
				zoomOutElem.removeAttribute('disabled');
				zoomInElem.removeAttribute('disabled');
			}
		},
		mapSearchChanged(place) {
			if (!this.$isObject(place.geometry)) {
				return;
			}
			this.map.searchChanged = true;
			console.log('Map: Place:', place);
			if (this.$isObject(place.geometry.viewport)) {
				console.log('Map: Place Viewport:', place.geometry.viewport);
				this.$refs.gmap.fitBounds(place.geometry.viewport);
			} else {
				this.map.center.lat = place.geometry.location.center.lat;
				this.map.center.lng = place.geometry.location.center.lng;
				this.map.zoom = 17;
			}
		}
	}
};
</script>

<style>
html {
	overflow-y: hidden;
}
.gm-style button:disabled {
	opacity: 0.5 !important;
	cursor: not-allowed !important;
}
</style>
