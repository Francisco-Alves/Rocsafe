/*------------------------------------------------------------------------------
 * Copyright (C) 2018 INOV INESC INOVACAO
 * All rights reserved.
 *------------------------------------------------------------------------------
 * $Id::                                                                      $
 *----------------------------------------------------------------------------*/

import 'typeface-roboto/index.css';
import 'material-design-icons-iconfont/dist/material-design-icons.css';
import 'vuetify/src/stylus/app.styl';

import Vue from 'vue';
import App from './App.vue';
import TypeCheckPlugin from './plugins/type-check.js';
import * as VueGoogleMaps from 'vue2-google-maps';
import {
	Vuetify,
	VApp,
	VGrid,
	VTextField,
	VToolbar
} from 'vuetify';

Vue.use(Vuetify, {
	components: {
		VApp,
		VGrid,
		VTextField,
		VToolbar
	}
});

Vue.use(VueGoogleMaps, {
	load: {
		key: 'AIzaSyARys16e8MBLhRMVjUlXHQ-RkDM6ay_IcI',
		language: 'en',
		libraries: 'places'
	}
});

Vue.use(TypeCheckPlugin);

new Vue({
	el: '#app',
	render: h => h(App)
});
