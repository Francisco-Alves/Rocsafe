$Id$

## WebRTC Client/Server Usage Example

###  Adapted from https://github.com/shanet/WebRTC-Example

### Changes made by INOV

- Converted to an example for a client-server connection, i.e., were one browser just send its local media while the other justs receives:
  - client/server.html & client/webrtc-server.js: Streaming server (sender) 
  - client/client.html & client/webrtc-client.js: Streaming client (receiver)
- ESLint comply and JSBeautify formating
- Setup without TLS keys:
  - You can use it at localhost for debugging purposes, i.e:
    - Server: http://localhost:3000/server
    - Client: http://localhost:3000/client
  - Serve this example in a Reverse Proxy setup to provide the required HTTPS connection, otherwise Chrome will block access to [getUserMedia()](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia) (see [Deprecating Powerful Features on Insecure Origins](https://goo.gl/rStTGz))
    - Server: https://{my_hostname}/webrtc/server
    - Client: https://{my_hostname}/webrtc/client
- Added multi-peer client functionality, i.e., multiple streaming clients can connect to the same streaming server.

See [README.md](./README.original.md) for the original example usage instructions.
