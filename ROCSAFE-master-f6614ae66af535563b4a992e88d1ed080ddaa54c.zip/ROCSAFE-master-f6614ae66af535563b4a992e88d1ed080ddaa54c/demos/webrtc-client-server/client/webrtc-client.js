/* $Id$ */

var remoteVideo;
var peerConnection = null;
var serverConnection = null;
var uuid;
var isChrome;

var peerConnectionConfig = {
	'iceServers': [{
		'urls': 'stun:stun.stunprotocol.org'
	}, {
		'urls': 'stun:stun1.l.google.com:19302'
	}]
};

window.addEventListener('load', init);
window.addEventListener('beforeunload', shutdown);

function init() {
	uuid = getUuid();
	console.info('CLIENT: INIT:', uuid);
	isChrome = !!window.chrome && !!window.chrome.webstore;
	adjustWindowPosition();
	var wsLocation;
	if (location.hostname === 'localhost') {
		wsLocation = 'ws://localhost:' + (Number(location.port) + 1);
	} else {
		wsLocation = 'wss://' + location.host + location.pathname.substring(0, location.pathname.lastIndexOf('/') + 1) + 'ws';
	}
	console.debug('CLIENT: WS:', wsLocation);
	remoteVideo = document.getElementById('remoteVideo');
	startServerConnection(wsLocation);
}

function shutdown() {
	console.info('CLIENT: SHUTDOWN');
	storeWindowLayout();
	if (peerConnection !== null) {
		console.info('CLIENT: Closing peer connection');
		peerConnection.close();
	}
	if (serverConnection !== null) {
		serverConnection.closing = true;
		serverConnection.close();
	}
}

function startServerConnection(uri) {
	console.info('CLIENT: Starting signalling connection to', uri);
	serverConnection = new WebSocket(uri);
	serverConnection.onmessage = gotMessageFromServer;
	serverConnection.onopen = function () {
		console.info('CLIENT: Signalling connection established');
		if (peerConnection === null) {
			startPeerConnection();
		}
	};
	serverConnection.onclose = function (event) {
		if (serverConnection.closing) {
			return;
		}
		console.warn('CLIENT: Signaling connection was closed. Restarting in 5 seconds...', event);
		setTimeout(function () {
			startServerConnection(uri);
		}, 5000);
	};
}

function startPeerConnection() {
	console.info('CLIENT: Starting peer connection');
	peerConnection = new RTCPeerConnection(peerConnectionConfig);
	peerConnection.onicecandidate = gotIceCandidate;
	peerConnection.ontrack = gotRemoteStream;
	peerConnection.oniceconnectionstatechange = handleICEConnectionStateChangeEvent;
	peerConnection.createOffer({
		offerToReceiveAudio: true,
		offerToReceiveVideo: true
	}).then(createdDescription).catch(errorHandler);
}

function gotMessageFromServer(message) {
	if (peerConnection === null) {
		startPeerConnection();
	}
	var signal = JSON.parse(message.data);
	// Ignore messages from ourself and to other clients
	if (signal.src === uuid || signal.dst !== uuid) {
		return;
	}
	console.debug('CLIENT: Got signalling message', signal);
	if (signal.sdp) {
		peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp)).catch(errorHandler);
	} else if (signal.ice) {
		peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice)).catch(errorHandler);
	}
}

function gotIceCandidate(event) {
	console.debug('CLIENT: Got ICE candidate', event);
	if (event.candidate !== null) {
		serverConnection.send(JSON.stringify({
			'ice': event.candidate,
			'src': uuid
		}));
	}
}

function createdDescription(description) {
	console.debug('CLIENT: Got description', description);
	peerConnection.setLocalDescription(description).then(function () {
		serverConnection.send(JSON.stringify({
			'sdp': peerConnection.localDescription,
			'src': uuid
		}));
	}).catch(errorHandler);
}

function gotRemoteStream(event) {
	console.debug('CLIENT: Got remote stream', event);
	remoteVideo.srcObject = event.streams[0];
}

function handleICEConnectionStateChangeEvent() {
	var state = peerConnection.iceConnectionState;
	console.info('CLIENT: ICE:', state);
	if (state === 'disconnected') {
		console.info('CLIENT: Closing peer connection');
		peerConnection.close();
	} else if (state === 'closed') {
		peerConnection = null;
	}
}

function errorHandler(error) {
	console.error('CLIENT: ' + error);
}

// Taken from http://stackoverflow.com/a/105074/515584
// Strictly speaking, it's not a real UUID, but it gets the job done here
function getUuid() {
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
	}
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}

function adjustWindowPosition() {
	if (isBaseWindowDown()) {
		return;
	}
	var val = localStorage.getItem(window.name + ':layout');
	var layout = JSON.parse(val);
	console.info('CLIENT: Adjust Window: Stored Layout:', layout);
	if (layout === null) {
		return;
	}
	var winLayout = {
		w: window.innerWidth,
		h: window.innerHeight,
		x: window.screenX,
		y: window.screenY
	};
	var dx = layout.x - winLayout.x;
	var dy = layout.y - winLayout.y;
	if (dx !== 0 || dy !== 0) {
		console.info('CLIENT: Window Position Adjust: Dx=' + dx + ' Dy=' + dy);
		if (isChrome) {
			window.moveTo(layout.x + dx, layout.y + dy);
		} else {
			window.moveBy(dx, dy);
		}
	}
	var dw = layout.w - winLayout.w;
	var dh = layout.h - winLayout.h;
	if (dw !== 0 || dh !== 0) {
		console.info('CLIENT: Window Size Adjust: Dw=' + dw + ' Dh=' + dh);
		window.resizeBy(dw, dh);
	}
}

function storeWindowLayout() {
	if (isBaseWindowDown()) {
		var winLayout = {
			w: window.innerWidth,
			h: window.innerHeight,
			x: window.screenX,
			y: window.screenY,
			video: true
		};
		console.info('CLIENT: Storing Layout:', winLayout);
		var val = JSON.stringify(winLayout);
		localStorage.setItem(window.name + ':layout', val);
	} else {
		localStorage.removeItem(window.name + ':layout');
	}
}

function isBaseWindowDown() {
	var winBaseName = window.name.substring(0, window.name.lastIndexOf('-') + 1);
	return localStorage.getItem(winBaseName + 0) === null;
}
