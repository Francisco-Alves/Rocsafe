/* $Id$ */

var localVideo;
var localStream = null;
var peerConnections = {};
var serverConnection = null;
var uuid;

var peerConnectionConfig = {
	'iceServers': [{
		'urls': 'stun:stun.stunprotocol.org'
	}, {
		'urls': 'stun:stun1.l.google.com:19302'
	}]
};

window.addEventListener('load', init);
window.addEventListener('beforeunload', shutdown);

function init() {
	uuid = getUuid();
	console.info('SERVER: INIT:', uuid);
	var wsLocation;
	if (location.hostname === 'localhost') {
		wsLocation = 'ws://localhost:' + (Number(location.port) + 1);
	} else {
		wsLocation = 'wss://' + location.host + location.pathname.substring(0, location.pathname.lastIndexOf('/') + 1) + 'ws';
	}
	console.debug('SERVER: WS:', wsLocation);
	localVideo = document.getElementById('localVideo');
	startLocalStream({
		video: true,
		audio: true
	});
	startServerConnection(wsLocation);
}

function shutdown() {
	console.info('SERVER: SHUTDOWN');
	for (var prop in peerConnections) {
		var pc = peerConnections[prop];
		console.info('SERVER:', pc.uuid, ': Closing peer connection');
		pc.close();
	}
	if (serverConnection !== null) {
		serverConnection.closing = true;
		serverConnection.close();
	}
}

function startLocalStream(constraints) {
	console.info('SERVER: Starting local stream', constraints);
	if (navigator.mediaDevices.getUserMedia) {
		navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
			console.info('SERVER: Got user media', stream);
			localStream = stream;
			localVideo.srcObject = stream;
			serverConnection.send(JSON.stringify({
				'inov': 'WebRTC Server started',
				'src': uuid
			}));
		}).catch(errorHandler);
	} else {
		alert('Your browser does not support getUserMedia API');
	}
}

function startServerConnection(uri) {
	console.info('SERVER: Starting signalling connection to', uri);
	serverConnection = new WebSocket(uri);
	serverConnection.onmessage = gotMessageFromServer;
	serverConnection.onopen = function () {
		console.info('SERVER: Signalling connection established');
	};
	serverConnection.onclose = function (event) {
		if (serverConnection.closing) {
			return;
		}
		console.warn('SERVER: Signaling connection was closed. Restarting in 5 seconds...', event);
		setTimeout(function () {
			startServerConnection(uri);
		}, 5000);
	};
}

function startPeerConnection(peerUuid) {
	console.info('SERVER:', peerUuid, ': Starting peer connection');
	var pc = new RTCPeerConnection(peerConnectionConfig);
	pc.uuid = peerUuid;
	pc.onicecandidate = function (event) {
		console.debug('SERVER:', pc.uuid, ': Got ICE candidate', event);
		if (event.candidate !== null) {
			serverConnection.send(JSON.stringify({
				'ice': event.candidate,
				'dst': pc.uuid,
				'src': uuid
			}));
		}
	};
	pc.oniceconnectionstatechange = function () {
		var state = pc.iceConnectionState;
		console.info('SERVER:', pc.uuid, ': ICE:', state);
		if (state === 'disconnected') {
			console.info('SERVER:', pc.uuid, ': Closing peer connection');
			pc.close();
		} else if (state === 'closed') {
			delete peerConnections[pc.uuid];
		}
	};
	if (localStream !== null) {
		localStream.getTracks().forEach(function (track) {
			pc.addTrack(track, localStream);
		});
	}
	return pc;
}

function gotMessageFromServer(message) {
	var signal = JSON.parse(message.data);
	// Ignore messages from ourself
	if (signal.src === uuid) {
		return;
	}
	var pc = peerConnections[signal.src];
	if (!pc) {
		pc = peerConnections[signal.src] = startPeerConnection(signal.src);
	}
	console.debug('SERVER: Got signalling message', signal);
	if (signal.sdp) {
		pc.setRemoteDescription(new RTCSessionDescription(signal.sdp)).then(function () {
			// Only create answers in response to offers
			if (signal.sdp.type === 'offer') {
				pc.createAnswer().then(function (description) {
					console.debug('SERVER:', pc.uuid, ': Got description', description);
					pc.setLocalDescription(description).then(function () {
						serverConnection.send(JSON.stringify({
							'sdp': pc.localDescription,
							'dst': pc.uuid,
							'src': uuid
						}));
					}).catch(errorHandler);
				}).catch(errorHandler);
			}
		}).catch(errorHandler);
	} else if (signal.ice) {
		pc.addIceCandidate(new RTCIceCandidate(signal.ice)).catch(errorHandler);
	}
}

function errorHandler(error) {
	console.error('SERVER: ' + error);
}

// Taken from http://stackoverflow.com/a/105074/515584
// Strictly speaking, it's not a real UUID, but it gets the job done here
function getUuid() {
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
	}
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}
