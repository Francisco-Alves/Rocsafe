<template>
  <v-app>
    <google-map ref="gmap" :center="{lat: 1.38, lng: 103.8}" :zoom="12" style="width: 100%; height: 100%">

    </google-map>
  </v-app>
</template>

<script>
import * as VueGoogleMaps from 'vue2-google-maps'
import GroundOverlay from './components/ground-overlay.vue';
import {
  loaded
} from 'vue2-google-maps';

  export default {
    components: {
      'google-map': VueGoogleMaps.Map,
      'ground-overlay' : GroundOverlay
    },
    data () {
      return {
        source: '../src/components/overlay.png',
        bounds:{ north: 1.502,
        south: 1.185,
        east: 104.0262,
        west: 103.5998}
      }

    },
    mounted() {
      loaded.then(() => {
        //this.GroundOverlay.addListener
        let mapObj = this.$refs.gmap.$mapObject;
        this.GroundOverlay = new google.maps.GroundOverlay(this.source, this.bounds);
        this.GroundOverlay.opacity = '0.5';
        this.GroundOverlay.setMap(mapObj);
      })
    }
  }
</script>
