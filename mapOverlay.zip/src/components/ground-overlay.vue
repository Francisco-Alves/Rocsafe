<template>
  <img src="./overlay.png"/>
</template>

<script>


export default {
  mappedProps: {
    'opacity': {}
  },
  props: {
    'source': {type: String},
    'bounds': {type: Object},
  },
  //events: ['click', 'dblclick'],
  name: 'groundOverlay',
  //ctr: () => google.maps.GroundOverlay,
  //ctrArgs: (options, {source, bounds}) => [source, bounds, options],


	}
</script>
